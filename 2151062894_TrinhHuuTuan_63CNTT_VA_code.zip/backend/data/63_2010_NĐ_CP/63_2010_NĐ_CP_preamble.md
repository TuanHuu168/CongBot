# 63_2010_NĐ_CP_preamble
# Nghị định số 63/2010/NĐ-CP của Chính phủ: Về kiểm soát thủ tục hành chính

| CHÍNH PHỦ ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập – Tự do – Hạnh phúc -------------- |
|---|---|
| Số: 63/2010/NĐ-CP | Hà Nội, ngày 08 tháng 06 năm 2010 |

NGHỊ ĐỊNH

VỀ KIỂM SOÁT THỦ TỤC HÀNH CHÍNH

CHÍNH PHỦ

Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001; Căn cứ Luật Ban hành văn bản quy phạm pháp luật ngày 03 tháng 6 năm 2008; Căn cứ Luật Ban hành văn bản quy phạm pháp luật của Hội đồng nhân dân, Ủy ban nhân dân ngày 03 tháng 12 năm 2004; Xét đề nghị của Bộ trưởng, Chủ nhiệm Văn phòng Chính phủ,