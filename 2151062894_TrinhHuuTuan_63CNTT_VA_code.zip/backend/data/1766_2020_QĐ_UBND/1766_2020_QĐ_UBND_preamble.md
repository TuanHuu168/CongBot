# 1766_2020_QĐ_UBND_preamble
# Thực hiện chế độ bảo hiểm y tế đối với đối tượng trực tiếp tham gia kháng chiến chống mỹ theo quyết định sô 290/2005/QĐ-TTg ngày 08 tháng 11 năm 2005 của Thủ tướng Chính phủ trên địa bàn thị xã Ninh Hòa của UBND tỉnh Khánh Hòa

| ỦY BAN NHÂN DÂN TỈNH BÌNH THUẬN -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc -------------------- |
|---|---|
| Số: 1766/QĐ-UBND | Bình Thuận, ngày 3 tháng 8 năm 2020 |

QUYẾT ĐỊNH

VỀ VIỆC CÔNG BỐ DANH MỤC THỦ TỤC HÀNH CHÍNH ĐƯỢC SỬA ĐỔI, BỔ SUNG, BÃI BỎ THUỘC PHẠM VI CHỨC NĂNG QUẢN LÝ CỦA NGÀNH TƯ PHÁP TRÊN ĐỊA BÀN TỈNH

CHỦ TỊCH ỦY BAN NHÂN DÂN TỈNH BÌNH THUẬN

Căn cứ Luật Tổ chức chính quyền địa phương ngày 19/6/2015; Luật Sửa đổi, bổ sung một số Điều của Luật Tổ chức Chính phủ và Luật Tổ chức chính quyền địa phương ngày 22/11/2019;

Căn cứ Nghị định số 63/2010/NĐ-CP ngày 08/6/2010 của Chính phủ về Kiểm soát thủ tục hành chính;

Căn cứ Nghị định số 48/2013/NĐ-CP ngày 14/5/2013 và Nghị định số 92/2017/NĐ-CP ngày 07/8/2017 của Chính phủ sửa đổi, bổ sung một số điều của các Nghị định liên quan đến kiểm soát thủ tục hành chính;

Căn cứ Thông tư số 02/2017/TT-VPCP ngày 31/10/2017 của Văn phòng Chính phủ hướng dẫn nghiệp vụ kiểm soát thủ tục hành chính;

Căn cứ Quyết định số 1217/QĐ-BT ngày 22/5/2020, Quyết định số 1183/QĐ-BTP ngày 20/5/2020, Quyết định số 1472/QĐ-BTP ngày 25/6/2020, Quyết định số 1329/QĐ-BTP ngày 01/6/2020, Quyết định số 1565/QĐ-BTP ngày 13/7/2020, Quyết định số 1566/QĐ-BTP ngày 13/7/2020 của Bộ Tư pháp về việc công bố thủ tục hành chính được sửa đổi, bổ sung, bãi bỏ trong các lĩnh vực quốc tịch; đăng ký biện pháp bảo đảm; phổ biến, giáo dục pháp luật; chứng thực; luật sư và tư vấn pháp luật thuộc phạm vi chức năng quản lý của Bộ Tư pháp;

Theo đề nghị của Giám đốc Sở Tư pháp.