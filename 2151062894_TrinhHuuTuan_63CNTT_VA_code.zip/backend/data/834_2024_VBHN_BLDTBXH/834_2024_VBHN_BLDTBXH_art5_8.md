# 834_2024_VBHN_BLDTBXH_art5_8

Chương III

CÁC CHẾ ĐỘ ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

Điều 5. Bảo hiểm y tế

Thực hiện đóng bảo hiểm y tế theo quy định của pháp luật về bảo hiểm y tế cho người có công với cách mạng, thân nhân và người phục vụ người có công với cách mạng theo quy định của Pháp lệnh Ưu đãi người có công với cách mạng.

Điều 6. Điều dưỡng phục hồi sức khỏe

1. Điều dưỡng phục hồi sức khỏe tại nhà: Mức chi bằng 0,9 lần mức chuẩn/01 người/01 lần và được chi trả trực tiếp cho đối tượng được hưởng.

2. Điều dưỡng phục hồi sức khỏe tập trung: Mức chi bằng 1,8 lần mức chuẩn/01 người/01 lần. Nội dung chi bao gồm:

a) Tiền ăn trong thời gian điều dưỡng;

b) Thuốc thiết yếu;

c) Quà tặng cho đối tượng;

d) Các khoản chi khác phục vụ trực tiếp cho đối tượng trong thời gian điều dưỡng (mức chi tối đa 15% mức chi điều dưỡng phục hồi sức khỏe tập trung), gồm: khăn mặt, xà phòng, bàn chải, thuốc đánh răng, tham quan, chụp ảnh, tư vấn sức khỏe, phục hồi chức năng, sách báo, hoạt động văn hóa, văn nghệ, thể thao và các khoản chi khác phục vụ đối tượng điều dưỡng.

Điều 7. Hỗ trợ phương tiện trợ giúp, dụng cụ chỉnh hình, phương tiện, thiết bị phục hồi chức năng cần thiết

1. Mức hỗ trợ mua phương tiện trợ giúp, dụng cụ chỉnh hình, phương tiện, thiết bị phục hồi chức năng cần thiết quy định tại Phụ lục V ban hành kèm theo Nghị định này.

2. Hỗ trợ tiền đi lại và tiền ăn cho đối tượng khi đi làm phương tiện trợ giúp, dụng cụ chỉnh hình (mỗi niên hạn 01 lần) hoặc đi điều trị phục hồi chức năng theo chỉ định của bệnh viện cấp tỉnh trở lên. Mức hỗ trợ 5.000 đồng/01 km/01 người tính theo khoảng cách từ nơi cư trú đến cơ sở y tế gần nhất đủ điều kiện về chuyên môn kỹ thuật cung cấp dụng cụ chỉnh hình, nhưng tối đa là 1.400.000 đồng/người/01 niên hạn.

Điều 8. Hỗ trợ ưu đãi giáo dục tại các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân đến trình độ đại học

1. Mức hưởng trợ cấp để theo học tại cơ sở giáo dục mầm non: 0,2 lần mức chuẩn/01 đối tượng/01 năm.

2. Mức hưởng trợ cấp để theo học tại cơ sở giáo dục phổ thông, giáo dục thường xuyên, trường dự bị đại học, trường năng khiếu, trường lớp dành cho người khuyết t t: 0,4 lần mức chuẩn/01 đối tượng/01 năm.

3. Mức hưởng trợ cấp để theo học tại cơ sở phổ thông dân tộc nội trú, giáo dục nghề nghiệp, giáo dục đại học: 0,4 lần mức chuẩn/01 đối tượng/01 năm.