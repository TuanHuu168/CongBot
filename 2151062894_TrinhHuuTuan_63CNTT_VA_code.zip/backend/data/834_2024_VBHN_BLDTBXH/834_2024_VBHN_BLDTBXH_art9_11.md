# 834_2024_VBHN_BLDTBXH_art9_11

Điều 9. Hỗ trợ thăm viếng mộ liệt sĩ

1. Hỗ trợ tiền đi lại và tiền ăn cho thân nhân liệt sĩ (tối đa 03 người) hoặc người thờ cúng liệt sĩ mỗi năm một lần khi đi thăm viếng một liệt sĩ.

2. Mức hỗ trợ tiền đi lại và tiền ăn tính theo khoảng cách từ nơi cư trú đến nơi có mộ liệt sĩ: 3.000 đồng/01 km/01 người.

Điều 10. Hỗ trợ di chuyển hài cốt liệt sĩ

1. Thân nhân liệt sĩ, người được thân nhân liệt sĩ ủy quyền, người thờ cúng liệt sĩ được hỗ trợ kinh phí một lần khi di chuyển hài cốt liệt sĩ:

a) Mức hỗ trợ tiền cất bốc hài cốt liệt sĩ 4.000.000 đồng/01 hài cốt liệt sĩ;

b) Mức hỗ trợ tiền đi lại và tiền ăn (tối đa 03 người) tính theo khoảng cách từ nơi cư trú đến nơi có mộ liệt sĩ: 3.000 đồng/01 km/01 người.

2. Thân nhân liệt sĩ hoặc người thờ cúng liệt sĩ không có nguyện vọng an táng hài cốt liệt sĩ trong nghĩa trang liệt sĩ thì được hỗ trợ một lần kinh phí xây mộ liệt sĩ. Mức hỗ trợ 10 triệu đồng/01 mộ.

Điều 11. Hỗ trợ công tác mộ liệt sĩ, công trình ghi công liệt sĩ

1. Hỗ trợ xây mới vỏ mộ liệt sĩ bao gồm cả bia ghi tên liệt sĩ: tối đa 10 triệu đồng/01 mộ (không gắn với dự án xây dựng, nâng cấp nghĩa trang); hỗ trợ cải tạo, nâng cấp, sửa chữa mộ liệt sĩ bao gồm cả bia ghi tên liệt sĩ: tối đa bằng 70% mức xây mới.

2. Hỗ trợ cải tạo, nâng cấp, sửa chữa, bảo trì nghĩa trang liệt sĩ theo dự án hoặc báo cáo kinh tế kỹ thuật được cơ quan có thẩm quyền phê duyệt.

3. Hỗ trợ cải tạo, nâng cấp, sửa chữa, bảo trì đài tưởng niệm liệt sĩ, đền thờ liệt sĩ, nhà bia ghi tên liệt sĩ: ngân sách trung ương hỗ trợ tối đa 15 tỷ đồng đối với công trình cấp tỉnh; 10 tỷ đồng đối với công trình cấp huyện; 02 tỷ đồng đối với công trình cấp xã, trong đó ngân sách trung ương hỗ trợ địa phương theo nguyên tắc:

a) Không hỗ trợ từ ngân sách trung ương đối với các địa phương tự cân đối ngân sách;

b) Hỗ trợ tối đa 50% tổng giá trị công trình được cơ quan có thẩm quyền phê duyệt đối với các địa phương có tỷ lệ điều tiết về ngân sách trung ương;

c) Hỗ trợ tối đa 70% tổng giá trị công trình được cơ quan có thẩm quyền phê duyệt đối với các địa phương chưa tự cân đối được ngân sách; riêng đối với các tỉnh miền núi, Tây Nguyên hỗ trợ tối đa 100% tổng giá trị công trình được cơ quan có thẩm quyền phê duyệt.