# 834_2024_VBHN_BLDTBXH_art3_4

Chương II

MỨC HƯỞNG TRỢ CẤP, PHỤ CẤP ƯU ĐÃI

Điều 3. Mức chuẩn trợ cấp ưu đãi3

1. Mức chuẩn trợ cấp ưu đãi người có công với cách mạng là 2.055.000 đồng (sau đây gọi tắt là mức chuẩn).

2. Mức chuẩn quy định tại khoản 1 Điều này làm căn cứ để tính mức hưởng trợ cấp, phụ cấp và các chế độ ưu đãi đối với người có công với cách mạng và thân nhân người có công với cách mạng. Các mức quy định theo mức chuẩn tại Nghị định này được điều chỉnh khi mức chuẩn được điều chỉnh và làm tròn đến hàng nghìn đồng.

Điều 4. Mức hưởng trợ cấp, phụ cấp ưu đãi4

1. Mức hưởng trợ cấp, phụ cấp ưu đãi hằng tháng đối với người có công với cách mạng và thân nhân của người có công với cách mạng được quy định tại Phụ lục I ban hành kèm theo Nghị định này.

2. Mức hưởng trợ cấp ưu đãi hằng tháng đối với thương binh, người hưởng chính sách như thương binh được quy định tại Phụ lục II ban hành kèm theo Nghị định này.

3. Mức hưởng trợ cấp ưu đãi hằng tháng đối với thương binh loại B được quy định tại Phụ lục III ban hành kèm theo Nghị định này.

4. Mức hưởng trợ cấp ưu đãi một lần đối với người có công với cách mạng và thân nhân người có công với cách mạng được quy định tại Phụ lục IV ban hành kèm theo Nghị định này. Trường hợp mức trợ cấp một lần tính theo thâm niên thì sau khi đã tính tròn số năm tham gia kháng chiến mà còn có tháng lẻ thì số tháng lẻ được tính tròn số theo nguyên tắc: từ đủ 06 tháng đến dưới 12 tháng được tính là 01 năm, dưới 06 tháng được tính là 06 tháng. Trường hợp không xác định được ngày, tháng bắt đầu hoạt động kháng chiến thì được tính từ ngày 01 tháng 7 của năm đó.