# 834_2024_VBHN_BLDTBXH_appendix4

PHỤ LỤC IV21

MỨC HƯỞNG TRỢ CẤP ƯU ĐÃI MỘT LẦN ĐỐI VỚI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG VÀ THÂN NHÂN CỦA NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

| STT | Đối tượng người có công | Mức trợ cấp |
|---|---|---|
| 1 | Người hoạt động cách mạng trước ngày 01 tháng 01 năm 1945 chết mà chưa được hưởng chế độ ưu đãi: |  |
| 1.1 | Thân nhân | 31,0 lần mức chuẩn |
| 1.2 | Người thờ cúng | 6,2 lần mức chuẩn |
| 2 | Người hoạt động cách mạng từ ngày 01 tháng 01 năm 1945 đến ngày khởi nghĩa tháng Tám năm 1945 chết mà chưa được hưởng chế độ ưu đãi: |  |
| 2.1 | Thân nhân | 15,5 lần mức chuẩn |
| 2.2 | Người thờ cúng | 6,2 lần mức chuẩn |
| 3 | Liệt sĩ |  |
|  | Trợ cấp một lần khi truy tặng Bằng “Tổ quốc ghi công” đối với thân nhân liệt sĩ hoặc người thừa kế của liệt sĩ | 20,0 lần mức chuẩn |
| Hỗ trợ chi phí báo tử | 1,0 lần mức chuẩn |  |
| 4 | Bà mẹ Việt Nam anh hùng được tặng danh hiệu nhưng chết mà chưa được hưởng chế độ ưu đãi hoặc được truy tặng danh hiệu “Bà mẹ Việt Nam anh hùng” | 20,0 lần mức chuẩn |
| 5 | Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến được tặng danh hiệu nhưng chết mà chưa được hưởng chế độ ưu đãi hoặc được truy tặng danh hiệu “Anh hùng lực lượng vũ trang nhân dân”, “Anh hùng Lao động” trong thời kỳ kháng chiến | 20,0 lần mức chuẩn |
| 6 | Người hoạt động cách mạng, kháng chiến, bảo vệ Tổ quốc, làm nghĩa vụ quốc tế bị địch bắt tù, đày chết mà chưa được hưởng chế độ ưu đãi | 1,5 lần mức chuẩn |
| 7 | Người hoạt động kháng chiến giải phóng dân tộc, bảo vệ Tổ quốc, làm nghĩa vụ quốc tế (Trợ cấp tính theo thâm niên kháng chiến) | 0,3 lần mức chuẩn/thâm niên |
| 8 | Người có công giúp đỡ cách mạng được tặng hoặc người trong gia đình được tặng Huy chương Kháng chiến | 1,5 lần mức chuẩn |
| 9 | Người hoạt động kháng chiến giải phóng dân tộc, bảo vệ Tổ quốc, làm nghĩa vụ quốc tế chết mà chưa được hưởng chế độ ưu đãi | 1,5 lần mức chuẩn |
| 10 | Người có công giúp đỡ cách mạng chết mà chưa được hưởng chế độ ưu đãi | 1,5 lần mức chuẩn |