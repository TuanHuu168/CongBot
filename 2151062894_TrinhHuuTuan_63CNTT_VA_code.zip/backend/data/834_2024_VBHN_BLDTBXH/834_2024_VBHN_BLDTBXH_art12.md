# 834_2024_VBHN_BLDTBXH_art12

Điều 12. Xác định danh tính hài cốt liệt sĩ

1. Lấy mẫu hài cốt liệt sĩ còn thiếu thông tin:

a) Khai quật, cất bốc, sửa lại vỏ mộ sau khi lấy mẫu hài cốt liệt sĩ, mức chi: 1.000.000 đồng/01 mộ;

b) Thuê phông, bạt; mua dụng cụ lấy mẫu, găng tay, cồn, rượu, vật tư và các chi phí khác: thanh toán theo thực tế;

c)5 Lấy mẫu hài cốt liệt sĩ: mức chi 50.000 đồng/01 mộ thực hiện lấy mẫu.

2.6 Lấy mẫu để đối chứng ADN theo dòng mẹ của liệt sĩ (sau đây gọi chung là mẫu đối chứng thân nhân liệt sĩ):

Cơ quan, đơn vị tổ chức đi lấy mẫu đối chứng thân nhân liệt sĩ: nội dung chi được thực hiện theo quy định tại điểm b khoản 1 Điều này; hỗ trợ người thuộc diện được lấy mẫu đối chứng thân nhân liệt sĩ: mức hỗ trợ 500.000 đồng/người”.

3.7 Bảo quản mẫu hài cốt liệt sĩ, mẫu đối chứng thân nhân liệt sĩ còn thiếu thông tin ở dạng thô trong thời gian chờ giám định ADN tại các cơ sở giám định ADN: Mức chi 500 đồng/01 mẫu/01 ngày”.

4.8 Xác định danh tính hài cốt liệt sĩ còn thiếu thông tin bằng phương pháp giám định ADN:

a) Giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin là dịch vụ sự nghiệp công sử dụng kinh phí ngân sách nhà nước thuộc lĩnh vực sự nghiệp đảm bảo xã hội được thực hiện bằng phương thức đặt hàng.

b) Mẫu thực hiện giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin bao gồm: mẫu hài cốt liệt sĩ và mẫu đối chứng thân nhân liệt sĩ.

c) Điều kiện đặt hàng:

Đặt hàng cung cấp dịch vụ giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin với các nhà cung cấp dịch vụ giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin (sau đây gọi tắt là nhà cung cấp dịch vụ giám định ADN) khi đáp ứng đồng thời các điều kiện sau:

Nhà cung cấp dịch vụ giám định ADN: là các đơn vị sự nghiệp công lập thuộc các bộ, ngành, cơ quan thuộc Chính phủ, các doanh nghiệp thuộc mọi thành phần kinh tế, các tổ chức, đơn vị có tư cách pháp nhân, có chức năng cung cấp dịch vụ giám định ADN được Bộ Lao động - Thương binh và Xã hội lựa chọn đặt hàng.

Dịch vụ giám định ADN hài cốt liệt sĩ và mẫu sinh phẩm thân nhân liệt sĩ có định mức kinh tế kỹ thuật và đơn giá, giá dịch vụ sự nghiệp công do cơ quan có thẩm quyền ban hành làm cơ sở để đặt hàng.

d) Phương thức thực hiện: đặt hàng.

Bộ trưởng Bộ Lao động - Thương binh và Xã hội quyết định đặt hàng dịch vụ giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin với các nhà cung cấp dịch vụ giám định ADN.

Căn cứ Quyết định đặt hàng được Bộ trưởng Bộ Lao động - Thương binh và Xã hội phê duyệt, Cục Người có công (Bộ Lao động - Thương binh và Xã hội) ký Hợp đồng đặt hàng cung cấp dịch vụ giám định ADN với các nhà cung cấp dịch vụ giám định ADN.

đ) Đơn giá đặt hàng:

Bộ trưởng Bộ Tài chính ban hành đơn giá tối đa dịch vụ giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin.

Bộ trưởng Bộ Lao động - Thương binh và Xã hội ban hành định mức kinh tế - kỹ thuật, định mức chi phí thực hiện dịch vụ giám định ADN xác định danh tính hài cốt liệt sĩ còn thiếu thông tin; quyết định đơn giá đặt hàng đảm bảo không vượt giá tối đa do Bộ trưởng Bộ Tài chính quy định.

e) Nội dung đặt hàng:

Số lượng mẫu thực hiện đặt hàng giám định ADN;

Chất lượng dịch vụ giám định ADN;

Thời gian triển khai và thời gian hoàn thành;

Đơn giá đặt hàng;

Giá trị hợp đồng đặt hàng;

Nguồn kinh phí đặt hàng;

Phương thức thanh toán, quyết toán;

Phương thức nghiệm thu, bàn giao sản phẩm;

Quyền và nghĩa vụ của đơn vị cung cấp dịch vụ giám định ADN;

Quyền và nghĩa vụ của cơ quan đặt hàng;

Các nội dung khác không trái với quy định của pháp luật.

5. Xác định hài cốt liệt sĩ còn thiếu thông tin bằng phương pháp thực chứng: Mức chi 3.000.000 đồng/một thông tin được xác minh chính xác về hài cốt liệt sĩ đối với các tổ chức, cá nhân cung cấp thông tin chính xác về hài cốt liệt sĩ.

6. Hoàn thiện mộ liệt sĩ bao gồm cả bia ghi tên liệt sĩ trong nghĩa trang liệt sĩ sau khi kết thúc việc giám định ADN:

a) Khai quật, hoàn trả mẫu hài cốt liệt sĩ đã có kết quả giám định, sửa lại vỏ mộ: mức chi 1.000.000 đồng/01 mộ;

b) Thuê phông, bạt và các chi phí khác: thanh toán theo thực tế.

7.9 Vận chuyển mẫu hài cốt liệt sĩ còn thiếu thông tin và mẫu đối chứng thân nhân liệt sĩ còn thiếu thông tin thanh toán theo thực tế.

8. Tổ chức lễ công bố kết quả danh tính hài cốt liệt sĩ:

a) Tổ chức lễ công bố kết quả danh tính hài cốt liệt sĩ: Nội dung và mức chi theo quy định hiện hành về tổ chức hội nghị;

b) Hỗ trợ thân nhân liệt sĩ hoặc người trong gia đình liệt sĩ đi nhận kết quả giám định ADN: Mức hỗ trợ tiền ăn, nghỉ, đi lại thực hiện theo chế độ công tác phí hiện hành (hỗ trợ tối đa 02 người). Trường hợp thân nhân liệt sĩ đi nhận từ 02 kết quả giám định ADN trở lên tại cùng một nơi tổ chức lễ công bố thì mức hỗ trợ được tính như đi nhận 01 kết quả giám định ADN.

9. Cơ sở dữ liệu về liệt sĩ:

a) Xây dựng, mua sắm, nâng cấp, tích hợp, vận hành hệ thống cơ sở dữ liệu về liệt sĩ, mộ liệt sĩ, nghĩa trang liệt sĩ, thân nhân liệt sĩ, ADN liệt sĩ, ADN thân nhân liệt sĩ đồng bộ trên phạm vi toàn quốc: thực hiện theo dự án do Bộ trưởng Bộ Lao động - Thương binh và Xã hội phê duyệt;

b) Điều tra, thu thập, cập nhật thông tin, tư liệu, duy trì và tạo lập cơ sở dữ liệu, phát triển hệ thống cung cấp thông tin về liệt sĩ, thân nhân liệt sĩ, ADN liệt sĩ, ADN thân nhân liệt sĩ, mộ liệt sĩ và nghĩa trang liệt sĩ.

10. Các nhiệm vụ khác phục vụ công tác xác định danh tính hài cốt liệt sĩ:

a) Mua sắm trang thiết bị, vật tư, phương tiện chuyên dùng đảm bảo công tác xác định danh tính hài cốt liệt sĩ;

b) Sửa chữa, duy tu, bảo dưỡng trang thiết bị, phương tiện phục vụ công tác xác định danh tính hài cốt liệt sĩ;

c) Đào tạo, bồi dưỡng nâng cao trình độ chuyên môn nghiệp vụ cho đội ngũ làm công tác xác định danh tính hài cốt liệt sĩ;

d) Chi hợp tác với các tổ chức, cá nhân trong và ngoài nước trong việc hỗ trợ kỹ thuật, kinh nghiệm và nguồn lực để xác định danh tính hài cốt liệt sĩ;

đ) Các nhiệm vụ khác thanh toán thực tế theo quy định hiện hành.