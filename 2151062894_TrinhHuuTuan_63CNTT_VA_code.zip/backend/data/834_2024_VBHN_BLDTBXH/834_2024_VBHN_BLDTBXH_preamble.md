# 834_2024_VBHN_BLDTBXH_preamble


| BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 834/VBHN-BLĐTBXH | Hà Nội, ngày 05 tháng 3 năm 2024 |

NGHỊ ĐỊNH

QUY ĐỊNH MỨC HƯỞNG TRỢ CẤP, PHỤ CẤP VÀ CÁC CHẾ ĐỘ ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

Nghị định số 75/2021/NĐ-CP ngày 24 tháng 7 năm 2021 của Chính phủ quy định mức hưởng trợ cấp, phụ cấp và các chế độ ưu đãi người có công với cách mạng, có hiệu lực kể từ ngày 15 tháng 9 năm 2021, được sửa đổi, bổ sung bởi:

Nghị định số 55/2023/NĐ-CP ngày 21 tháng 7 năm 2023 của Chính phủ sửa đổi, bổ sung một số điều của Nghị định số 75/2021/NĐ-CP ngày 24 tháng 7 năm 2021 của Chính phủ quy định mức hưởng trợ cấp, phụ cấp và các chế độ ưu đãi người có công với cách mạng, có hiệu lực kể từ ngày 05 tháng 9 năm 2023.

Căn cứ Luật Tổ chức Chính phủ ngày 19 tháng 6 năm 2015; Luật sửa đổi, bổ sung một số điều của Luật Tổ chức Chính phủ và Luật Tổ chức chính quyền địa phương ngày 22 tháng 11 năm 2019;

Căn cứ Pháp lệnh Ưu đãi người có công với cách mạng ngày 09 tháng 12 năm 2020;

Theo đề nghị của Bộ trưởng Bộ Lao động - Thương binh và Xã hội;

Chính phủ ban hành Nghị định quy định mức hưởng trợ cấp, phụ cấp và các chế độ ưu đãi người có công với cách mạng1.