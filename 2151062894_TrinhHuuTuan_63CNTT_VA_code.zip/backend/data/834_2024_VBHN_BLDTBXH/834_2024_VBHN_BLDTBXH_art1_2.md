# 834_2024_VBHN_BLDTBXH_art1_2

Chương I

QUY ĐỊNH CHUNG

Điều 1. Phạm vi điều chỉnh2

Nghị định này quy định về mức hưởng trợ cấp, phụ cấp ưu đãi người có công với cách mạng, thân nhân của người có công với cách mạng và các chế độ ưu đãi đối với người có công với cách mạng từ nguồn ngân sách trung ương thực hiện Pháp lệnh Ưu đãi người có công với cách mạng được bố trí trong dự toán ngân sách nhà nước chi thường xuyên hằng năm của Bộ Lao động - Thương binh và Xã hội, Bộ Quốc phòng, Bộ Công an.

Điều 2. Đối tượng áp dụng

Đối tượng áp dụng theo quy định tại Điều 2 Pháp lệnh số 02/2020/UBTVQH14 ngày 09 tháng 12 năm 2020 của Ủy ban Thường vụ Quốc hội khóa XIV về Ưu đãi người có công với cách mạng.