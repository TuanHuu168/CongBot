# 49_2012_QĐ_UBND_regulation_ch2_art9
Điều 9. Các đơn vị thuộc Sở Lao động - Thương binh và Xã hội có nhiệm vụ

1. Quản lý kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến; Mở tài khoản dự toán tại Kho bạc Nhà nước nơi đơn vị đóng trụ sở để theo dõi nguồn kinh phí được giao; Mở sổ sách theo dõi kinh phí chi trả, lưu giữ chứng từ, hồ sơ sổ sách, thanh quyết toán tài chính theo quy định hiện hành của Nhà nước.

2. Lập dự toán kinh phí thực hiện chính sách người có công với cách mạng và người trực tiếp tham gia kháng chiến của năm kế hoạch báo cáo về Sở Lao động - Thương binh và Xã hội trước ngày 20 tháng 6 hàng năm.

3. Căn cứ dự toán được Sở Lao động - Thương binh và Xã hội giao, đơn vị thực hiện rút dự toán tại Kho bạc Nhà nước để triển khai nhiệm vụ.

4. Hàng quý, năm lập báo cáo quyết toán kinh phí chi trả trợ cấp ưu đãi trên địa bàn đúng biểu mẫu theo quy định tại Quyết định số 19/2006/QĐ-BTC ngày 30 tháng 3 năm 2006 của Bộ trưởng Bộ Tài chính và Quyết định số 09/2007/QĐ-LĐTBXH ngày 30 tháng 3 năm 2007 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội, gửi Sở Lao động - Thương binh và Xã hội chậm nhất sau khi kết thúc quý 15 ngày (đối với báo cáo quý) và trước ngày 30 tháng 4 hàng năm (đối với báo cáo năm).