# 49_2012_QĐ_UBND_regulation_ch2_art6_7
Điều 6. Ủy ban nhân dân quận - huyện có nhiệm vụ

1. Chỉ đạo Phòng Lao động - Thương binh và Xã hội quận - huyện, Ủy ban nhân dân phường - xã, thị trấn thực hiện tốt công tác quản lý đối tượng, quản lý kinh phí, tiền mặt, xây dựng dự toán hàng năm, chấp hành dự toán được Sở Lao động - Thương binh và Xã hội giao, báo cáo quyết toán đúng nội dung và thời gian quy định; xử lý nghiêm các trường hợp sai phạm theo quy định của Nhà nước.

2. Định kỳ chỉ đạo, kiểm tra công tác quản lý đối tượng, chi trả trợ cấp ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến và các nguồn kinh phí khác thuộc Phòng Lao động - Thương binh và Xã hội quận - huyện quản lý, sử dụng.

Điều 7. Phòng Lao động - Thương binh và Xã hội quận - huyện có nhiệm vụ

1. Quản lý đối tượng, quản lý kinh phí thực hiện chính sách người có công với cách mạng và người trực tiếp tham gia kháng chiến trên địa bàn; Mở tài khoản tại Kho bạc Nhà nước cấp quận để theo dõi nguồn kinh phí được giao. Mở sổ sách theo dõi đối tượng, kinh phí chi trả, quản lý, lưu trữ chứng từ, hồ sơ sổ sách, thanh quyết toán theo quy định hiện hành của Nhà nước.

2. Quản lý chi trả trợ cấp ưu đãi giáo dục và trang cấp dụng cụ chỉnh hình theo quy định kèm theo Sổ ưu đãi giáo dục, sổ trang cấp. Lập danh sách trích ngang những đối tượng được hưởng đúng tiêu chuẩn gửi về Sở Lao động - Thương binh và Xã hội.

3. Lập dự toán kinh phí chi trả trợ cấp ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến của năm kế hoạch báo cáo về Sở Lao động - Thương binh và Xã hội trước ngày 20 tháng 6 hàng năm.

4. Phối hợp với Bảo hiểm xã hội Thành phố để mua, cấp và báo giảm thẻ bảo hiểm y tế cho đối tượng kịp thời. Đối với các đối tượng di chuyển đi tỉnh, thành phố khác hoặc đối tượng chết lập danh sách báo giảm hàng tháng để có căn cứ thanh toán.

5. Hàng tháng kiểm tra, rà soát đối tượng giảm báo cáo về Sở Lao động - Thương binh và Xã hội trước ngày 22 hàng tháng. Đối với những trường hợp người có công đang hưởng trợ cấp ưu đãi hàng tháng nếu trong một năm (01 năm) không đến nhận trợ cấp, Phòng Lao động - Thương binh và Xã hội quận - huyện có công văn kèm danh sách trích ngang đối tượng đề nghị Sở Lao động - Thương binh và Xã hội tạm dừng chi trả trợ cấp.

Rà soát, kiểm tra chi tiết, đối chiếu danh sách chi trả trợ cấp hàng tháng trước khi làm các thủ tục tạm ứng kinh phí xuống các phường - xã, thị trấn.

6. Lập danh sách và chi trả cho đối tượng được cấp Báo Nhân dân, tiền ăn thêm ngày lễ, tết, đối tượng hưởng trợ cấp một lần (không mang tính chất thường xuyên) và đối tượng hưởng điều dưỡng.

7. Căn cứ vào dự toán được Sở Lao động - Thương binh và Xã hội giao, hàng tháng Phòng Lao động - Thương binh và Xã hội quận - huyện rút dự toán chuyển kinh phí cho các phường - xã, thị trấn (vào tài khoản tiền gửi của Ủy ban nhân dân phường - xã, thị trấn) chi tạm ứng các khoản trợ cấp ưu đãi người có công với cách mạng chậm nhất là ngày 10 hàng tháng. Cuối tháng thanh toán với Ủy ban nhân dân phường - xã, thị trấn số tiền đã chi trả trợ cấp cho người có công và thanh toán tạm ứng với Kho bạc Nhà nước.

8. Trưởng Phòng Lao động - Thương binh và Xã hội quận - huyện trực tiếp ký hợp đồng trách nhiệm với Chủ tịch Ủy ban nhân dân phường - xã, thị trấn về việc chi trả trợ cấp ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến, theo mẫu số C74-HĐ/LĐTBXH ban hành theo Quyết định số 09/2007/QĐ-LĐTBXH ngày 30 tháng 3 năm 2007 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội.

9. Hàng quý, năm lập báo cáo quyết toán kinh phí chi trả trợ cấp ưu đãi trên địa bàn đúng biểu mẫu theo quy định tại Quyết định số 19/2006/QĐ-BTC ngày 30 tháng 3 năm 2006 của Bộ trưởng Bộ Tài chính và Quyết định số 09/2007/QĐ-LĐTBXH ngày 30 tháng 3 năm 2007 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội, gửi Sở Lao động - Thương binh và Xã hội chậm nhất sau khi kết thúc quý 15 ngày (đối với báo cáo quý) và trước ngày 30 tháng 4 hàng năm (đối với báo cáo năm).

10. Thường xuyên kiểm tra, hướng dẫn Ủy ban nhân dân phường - xã, thị trấn thực hiện đúng quy định của Nhà nước trong công tác quản lý đối tượng, chi trả trợ cấp chế độ ưu đãi, bảo quản lưu trữ hồ sơ chứng từ gốc. Nếu phát hiện thấy sai phạm, kịp thời báo cáo Ủy ban nhân dân quận - huyện và Sở Lao động - Thương binh và Xã hội xem xét, xử lý theo quy định pháp luật.

Phòng Lao động - Thương binh và Xã hội quận - huyện phải thực hiện kiểm tra việc thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến tại tất cả các phường - xã, thị trấn tối thiểu một lần/năm.