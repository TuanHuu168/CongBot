# 49_2012_QĐ_UBND_preamble
# Ban hành quy chế quản lý kinh phí chi thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến trên địa bàn Thành phố Hồ Chí Minh

| ỦY BAN NHÂN DÂN THÀNH PHỐ HỒ CHÍ MINH -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 49/2012/QĐ-UBND | Thành phố Hồ Chí Minh, ngày 23 tháng 10 năm 2012 |

QUYẾT ĐỊNH

BAN HÀNH QUY CHẾ QUẢN LÝ KINH PHÍ CHI THỰC HIỆN CHÍNH SÁCH ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG VÀ NGƯỜI TRỰC TIẾP THAM GIA KHÁNG CHIẾN TRÊN ĐỊA BÀN THÀNH PHỐ HỒ CHÍ MINH

ỦY BAN NHÂN DÂN THÀNH PHỐ HỒ CHÍ MINH

Căn cứ Luật Tổ chức Hội đồng nhân dân và Ủy ban nhân dân ngày 26 tháng 11 năm 2003;

Căn cứ Luật Ngân sách nhà nước ngày 16 tháng 12 năm 2002;

Căn cứ Pháp lệnh Ưu đãi người có công với cách mạng ngày 29 tháng 6 năm 2005;

Căn cứ Pháp lệnh sửa đổi, bổ sung một số điều của Pháp lệnh Ưu đãi người có công với cách mạng ngày 16 tháng 7 năm 2012;

Căn cứ Nghị định số 54/2006/NĐ-CP ngày 26 tháng 5 năm 2006 của Chính phủ hướng dẫn thi hành một số điều của Pháp lệnh Ưu đãi người có công với cách mạng;

Căn cứ Thông tư liên tịch số 47/2009/TTLT-BTC-BLĐTBXH ngày 11 tháng 3 năm 2009 của Bộ Tài chính - Bộ Lao động - Thương binh và Xã hội hướng dẫn cấp phát, quản lý và sử dụng kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến do ngành Lao động - Thương binh và Xã hội quản lý;

Xét đề nghị của Giám đốc Sở Lao động - Thương binh và Xã hội tại Tờ trình số 4965/LĐTBXH-KH ngày 23 tháng 5 năm 2012 và ý kiến của Sở Tài chính tại Công văn số 9622/STC-HCSN ngày 05 tháng 10 năm 2012,