# 49_2012_QĐ_UBND_regulation_ch3
Chương III

XỬ LÝ VI PHẠM VÀ TỔ CHỨC THỰC HIỆN

Điều 10. Xử lý vi phạm

Cơ quan, tổ chức, cá nhân nếu vi phạm, gây thiệt hại, thất thoát kinh phí thì tùy theo mức độ sẽ xử lý kỷ luật hoặc truy cứu trách nhiệm hình sự theo quy định của pháp luật.

Điều 11. Tổ chức thực hiện

Công tác cấp phát, quản lý, thanh quyết toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến do ngành Lao động - Thương binh và Xã hội quản lý. Giám đốc Sở Lao động - Thương binh và Xã hội chủ trì hướng dẫn và phối hợp với Kho bạc Nhà nước Thành phố thường xuyên kiểm tra việc thực hiện Quy chế này.

Trong quá trình thực hiện nếu có vướng mắc, Ủy ban nhân dân các cấp, Phòng Lao động - Thương binh và Xã hội quận - huyện, các đơn vị thuộc Sở Lao động - Thương binh và Xã hội phản ánh kịp thời về Sở Lao động - Thương binh và Xã hội để tổng hợp, đề xuất Ủy ban nhân dân Thành phố bổ sung, sửa đổi cho phù hợp.