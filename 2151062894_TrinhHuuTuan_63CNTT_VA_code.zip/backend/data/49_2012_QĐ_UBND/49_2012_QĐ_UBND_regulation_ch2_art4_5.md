# 49_2012_QĐ_UBND_regulation_ch2_art4_5
Chương II

QUYỀN HẠN, TRÁCH NHIỆM CỦA CÁC NGÀNH VÀ CÁC CẤP NGÂN SÁCH

Điều 4. Sở Lao động - Thương binh và Xã hội có nhiệm vụ

1. Thẩm tra dự toán kinh phí hàng năm thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến của Phòng Lao động - Thương binh và Xã hội các quận - huyện, các đơn vị thuộc Sở Lao động - Thương binh và Xã hội có sử dụng kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến gồm: Ban Quản trang thành phố, Sở Lao động - Thương binh và Xã hội (phần chi tại Sở, gọi chung là các đơn vị thuộc Sở), tổng hợp thành dự toán kinh phí của Thành phố báo cáo Bộ Lao động - Thương binh và Xã hội trước ngày 05 tháng 7 hàng năm.

2. Căn cứ vào Quyết định giao dự toán ngân sách nhà nước hàng năm của Bộ Lao động - Thương binh và Xã hội, Giám đốc Sở Lao động - Thương binh và Xã hội phân bổ và ban hành Quyết định giao dự toán cho các Phòng Lao động - Thương binh và Xã hội quận - huyện, các đơn vị thuộc Sở, đồng thời gửi Kho bạc Nhà nước để làm căn cứ kiểm soát chi theo quy định của pháp luật.

3. Trên cơ sở đề nghị của đơn vị, xác nhận của Kho bạc Nhà nước về số dư dự toán được giao còn lại và khả năng sử dụng kinh phí của các Phòng Lao động - Thương binh và Xã hội quận - huyện, các đơn vị thuộc Sở Lao động - Thương binh và Xã hội, Giám đốc Sở Lao động - Thương binh và Xã hội ban hành Quyết định điều chỉnh dự toán giữa các đơn vị sử dụng ngân sách đồng thời gửi Kho bạc Nhà nước dự toán điều chỉnh để phối hợp thực hiện.

4. Lập Bảng kê tăng và in danh sách chi trả trợ cấp hàng tháng cho các Phòng Lao động - Thương binh và Xã hội quận - huyện. Ban hành văn bản tạm dừng chi trả khi có văn bản đề nghị của Phòng Lao động - Thương binh và Xã hội quận - huyện.

5. Thẩm tra, xét duyệt, thông báo kết quả thực hiện dự toán, quyết toán kinh phí hàng quý, năm cho các Phòng Lao động - Thương binh và Xã hội cấp quận, các đơn vị thuộc Sở. Định kỳ kiểm tra việc quản lý chi trả trợ cấp cho đối tượng chính sách ở các Phòng Lao động - Thương binh và Xã hội quận - huyện.

6. Tổng hợp báo cáo quyết toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến của Thành phố gửi về Bộ Lao động - Thương binh và Xã hội trước ngày 05 tháng 7 hàng năm.

7. Tổ chức hướng dẫn nghiệp vụ cho các Phòng Lao động - Thương binh và Xã hội quận - huyện, các đơn vị thuộc Sở những quy định chung về chế độ tài chính, kế toán hành chính sự nghiệp và những quy định riêng về chế độ tài chính kế toán chuyên ngành. Chỉ đạo công tác quản lý, tổ chức thực hiện chi trả trợ cấp ưu đãi cho các đối tượng chính sách trên địa bàn thành phố.

8. Phối hợp với các Phòng Lao động - Thương binh và Xã hội quận - huyện kiểm tra việc thực hiện chính sách tại các phường - xã, thị trấn.

Điều 5. Kho bạc Nhà nước Thành phố, Kho bạc Nhà nước quận - huyện có nhiệm vụ

1. Hướng dẫn mở tài khoản rút dự toán; thanh toán và kiểm soát chi nguồn kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến theo đúng quy định tại Điều 14 Thông tư liên tịch số 47/2009/TTLT-BTC-BLĐTBXH ngày 11 tháng 3 năm 2009 của Bộ Tài chính, Bộ Lao động - Thương binh và Xã hội và các quy định hiện hành.

2. Hàng tháng Kho bạc Nhà nước quận - huyện căn cứ Giấy rút dự toán và hồ sơ chứng từ có liên quan của Phòng Lao động - Thương binh và Xã hội quận - huyện, thực hiện chuyển khoản kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến, từ tài khoản dự toán của Phòng Lao động - Thương binh và Xã hội về tài khoản tiền gửi của Ủy ban nhân dân phường - xã, thị trấn (trong vòng 02 ngày làm việc kể từ khi nhận chứng từ hợp lệ) để thực hiện chi trả trợ cấp hàng tháng kịp thời và đầy đủ cho đối tượng chính sách.