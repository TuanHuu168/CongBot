# 48_2013_NĐ_CP_art1_part2
4. Sửa đổi Điều 11:

“Điều 11. Thẩm định quy định về thủ tục hành chính

1. Ngoài việc thẩm định nội dung dự án, dự thảo văn bản quy phạm pháp luật, cơ quan thẩm định có trách nhiệm thẩm định quy định về thủ tục hành chính và thể hiện nội dung này trong Báo cáo thẩm định.

2. Nội dung thẩm định thủ tục hành chính chủ yếu xem xét các tiêu chí quy định tại Điều 10 của Nghị định này.

3. Ngoài thành phần hồ sơ gửi thẩm định theo quy định của pháp luật về ban hành văn bản quy phạm pháp luật, cơ quan gửi thẩm định phải có bản đánh giá tác động về thủ tục hành chính theo quy định tại Điều 10 của Nghị định này.

Cơ quan thẩm định không tiếp nhận hồ sơ gửi thẩm định nếu dự án, dự thảo văn bản quy phạm pháp luật có quy định về thủ tục hành chính chưa có bản đánh giá tác động về thủ tục hành chính và ý kiến góp ý của cơ quan cho ý kiến quy định tại Khoản 1 Điều 9 của Nghị định này.”

5. Sửa đổi về thời hạn ban hành quyết định công bố tại Điều 15:

“Điều 15. Quyết định công bố thủ tục hành chính

Quyết định công bố thủ tục hành chính của các cơ quan quy định tại Khoản 1 Điều 13 của Nghị định này phải được ban hành chậm nhất trước 20 (hai mươi) ngày làm việc tính đến ngày văn bản quy phạm pháp luật có quy định về thủ tục hành chính có hiệu lực thi hành.

Quyết định công bố thủ tục hành chính của các cơ quan quy định tại các Khoản 2 và 3 Điều 13 của Nghị định này phải được ban hành chậm nhất trước 05 (năm) ngày làm việc tính đến ngày văn bản quy phạm pháp luật có quy định về thủ tục hành chính có hiệu lực thi hành.”.

6. Sửa đổi Khoản 2 Điều 22:

“Điều 22. Phản ánh, kiến nghị về thủ tục hành chính trong quá trình thực hiện

2. Bộ Tư pháp chịu trách nhiệm thiết lập, duy trì hoạt động của cổng thông tin phản ánh, kiến nghị, kết quả giải quyết về thủ tục hành chính trên Cơ sở dữ liệu quốc gia về thủ tục hành chính và chủ động tổ chức lấy ý kiến cá nhân, tổ chức về thủ tục hành chính quy định trong dự án, dự thảo văn bản quy phạm pháp luật do cơ quan chủ trì soạn thảo gửi lấy ý kiến theo quy định tại Khoản 2 Điều 9 của Nghị định này.”