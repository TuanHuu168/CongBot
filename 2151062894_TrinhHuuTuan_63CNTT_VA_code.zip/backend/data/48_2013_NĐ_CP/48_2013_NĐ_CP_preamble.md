# 48_2013_NĐ_CP_preamble
# Nghị định số 48/2013/NĐ-CP của Chính phủ: Sửa đổi, bổ sung một số điều của các Nghị định liên quan đến kiểm soát thủ tục hành chính

| CHÍNH PHỦ -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------- |
|---|---|
| Số: 48/2013/NĐ-CP | Hà Nội, ngày 14 tháng 05 năm 2013 |

NGHỊ ĐỊNH

SỬA ĐỔI, BỔ SUNG MỘT SỐ ĐIỀU CỦA CÁC NGHỊ ĐỊNH LIÊN QUAN ĐẾN KIỂM SOÁT THỦ TỤC HÀNH CHÍNH

Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001;

Căn cứ Luật Ban hành văn bản quy phạm pháp luật ngày 03 tháng 6 năm 2008;

Theo đề nghị của Bộ trưởng Bộ Tư pháp;

Chính phủ ban hành Nghị định sửa đổi, bổ sung một số điều của Nghị định số 63/2010/NĐ-CP ngày 08 tháng 6 năm 2010 của Chính phủ về kiểm soát thủ tục hành chính; Nghị định số 20/2008/NĐ-CP ngày 14 tháng 02 năm 2008 của Chính phủ về tiếp nhận, xử lý phản ánh, kiến nghị của cá nhân, tổ chức về quy định hành chính; Nghị định số 36/2012/NĐ-CP ngày 18 tháng 4 năm 2012 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ, cơ quan ngang Bộ và Nghị định số 55/2011/NĐ-CP ngày 04 tháng 7 năm 2011 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và tổ chức bộ máy của tổ chức pháp chế,