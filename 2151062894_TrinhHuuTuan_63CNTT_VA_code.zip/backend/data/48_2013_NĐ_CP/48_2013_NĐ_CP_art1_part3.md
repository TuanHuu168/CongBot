# 48_2013_NĐ_CP_art1_part3
7. Bãi bỏ Khoản 5 Điều 29.

8. Sửa đổi Khoản 4 Điều 30:

“Điều 30. Kế hoạch rà soát, đánh giá

4. Trên cơ sở chỉ đạo của Chính phủ, Thủ tướng Chính phủ và yêu cầu cải cách thủ tục hành chính, Bộ Tư pháp xây dựng kế hoạch rà soát trọng tâm, trình Thủ tướng Chính phủ phê duyệt.”

9. Sửa đổi, bổ sung Điều 31:

“Điều 31. Xử lý kết quả rà soát, đánh giá

1. Trên cơ sở kết quả rà soát, đánh giá thủ tục hành chính, Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương sửa đổi, bổ sung, thay thế, hủy bỏ hoặc bãi bỏ thủ tục hành chính theo thẩm quyền; đề nghị các Bộ, cơ quan ngang Bộ xem xét, xử lý kết quả rà soát, đánh giá thủ tục hành chính thuộc phạm vi, chức năng quản lý của Bộ, cơ quan ngang Bộ.

2. Trên cơ sở kết quả rà soát, đánh giá thủ tục hành chính của Bộ, cơ quan ngang Bộ và đề nghị của Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương, Bộ trưởng, Thủ trưởng cơ quan ngang Bộ sửa đổi, bổ sung, thay thế, hủy bỏ hoặc bãi bỏ theo thẩm quyền hoặc tổng hợp phương án sửa đổi, bổ sung, thay thế, hủy bỏ hoặc bãi bỏ thủ tục hành chính, các quy định có liên quan thuộc phạm vi thẩm quyền của Chính phủ, Thủ tướng Chính phủ, gửi Bộ Tư pháp xem xét, đánh giá trước khi trình Chính phủ, Thủ tướng Chính phủ.

Hồ sơ gửi Bộ Tư pháp xem xét, đánh giá, gồm:

- Dự thảo tờ trình;

- Dự thảo văn bản phê duyệt phương án đơn giản hóa thủ tục hành chính;

- Báo cáo kết quả rà soát của Bộ, cơ quan ngang Bộ;

- Báo cáo kết quả rà soát của Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương và của các cơ quan kèm theo phương án đơn giản hóa thủ tục hành chính đã được Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương hoặc Thủ trưởng cơ quan phê duyệt (nếu có).

Bộ, cơ quan ngang Bộ có trách nhiệm nghiên cứu, tiếp thu, giải trình ý kiến xem xét, đánh giá của Bộ Tư pháp về phương án sửa đổi, bổ sung, thay thế, hủy bỏ hoặc bãi bỏ thủ tục hành chính, các quy định có liên quan thuộc phạm vi thẩm quyền của Chính phủ, Thủ tướng Chính phủ.

3. Bộ Tư pháp chịu trách nhiệm theo dõi, đôn đốc, kiểm tra các Bộ, cơ quan ngang Bộ, Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương thực hiện quyết định phê duyệt phương án sửa đổi, bổ sung, thay thế, hủy bỏ hoặc bãi bỏ thủ tục hành chính, các quy định có liên quan của Chính phủ, Thủ tướng Chính phủ.”