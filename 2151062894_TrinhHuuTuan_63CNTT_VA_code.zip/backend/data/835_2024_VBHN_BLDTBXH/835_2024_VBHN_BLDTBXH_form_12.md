# 835_2024_VBHN_BLDTBXH_form_12

Mẫu số 1222

| UBND TỈNH, (TP)...... ------- |  |
|---|---|

DANH SÁCH THANH NIÊN XUNG PHONG ĐƯỢC HƯỞNG CHẾ ĐỘ TRỢ CẤP MỘT LẦN (Kèm theo Quyết định số .../QĐ-UBND ngày.../.../.... của UBND tỉnh ....)

Đơn vị: Đồng

| Số TT | Họ và tên | Ngày, tháng, năm sinh | Số định danh cá nhân/Chứng minh nhân dân, cấp ngày tháng năm, nơi cấp | Số năm được hưởng | Mức trợ cấp |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  | Cộng |  |  |  |  |

| NGƯỜI LẬP (Ký, ghi rõ họ và tên) | ........, ngày ... tháng... năm ...... TM. ỦY BAN NHÂN DÂN CHỦ TỊCH (Ký, họ và tên, đóng dấu) |
|---|---|