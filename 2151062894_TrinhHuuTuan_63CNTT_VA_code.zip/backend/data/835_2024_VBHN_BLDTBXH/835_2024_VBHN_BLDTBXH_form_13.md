# 835_2024_VBHN_BLDTBXH_form_13

Mẫu số 1323

| UBND TỈNH, (TP)...... ------- |  |
|---|---|

DANH SÁCH THÂN NHÂN CỦA THANH NIÊN XUNG PHONG ĐÃ TỪ TRẦN ĐƯỢC HƯỞNG CHẾ ĐỘ TRỢ CẤP MỘT LẦN (Kèm theo Quyết định số .../QĐ-UBND ngày.../.../.... của UBND tỉnh ....)

Đơn vị: Đồng

| Số TT | Họ và tên TNXP | Họ và tên thân nhân TNXP | Ngày, tháng, năm sinh | Số định danh cá nhân/Chứng minh nhân dân, cấp ngày tháng năm, nơi cấp | Quan hệ với TNXP | Mức trợ cấp |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  | Cộng |  |  |  |  |  |

| NGƯỜI LẬP (Ký, ghi rõ họ và tên) | ........, ngày ... tháng... năm ...... TM. ỦY BAN NHÂN DÂN CHỦ TỊCH (Ký, họ và tên, đóng dấu) |
|---|---|