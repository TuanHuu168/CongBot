# 835_2024_VBHN_BLDTBXH_form_9

Mẫu số 919

| UBND TỈNH, (TP)...... ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: /QĐ-UBND | ......., ngày ... tháng... năm ...... |

QUYẾT ĐỊNH

Về việc giải quyết chế độ trợ cấp một lần đối với thanh niên xung phong

ỦY BAN NHÂN DÂN TỈNH (THÀNH PHỐ)........

Căn cứ Quyết định số 40/2011/QĐ-TTg ngày 27 tháng 7 năm 2011 của Thủ tướng Chính phủ quy định về chế độ đối với thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến;

Căn cứ Thông tư liên tịch số 08/2012/TTLT-BLĐTBXH-BTC-BNV ngày 16 tháng 4 năm 2012 của Bộ Lao động - Thương binh và Xã hội, Bộ Nội vụ, Bộ Tài chính hướng dẫn thực hiện chế độ trợ cấp đối với thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến theo Quyết định số 40/2011/QĐ-TTg ngày 27 tháng 7 năm 2011 của Thủ tướng Chính phủ;

Theo đề nghị của Giám đốc Sở Nội vụ,

QUYẾT ĐỊNH

Điều 1. Giải quyết chế độ trợ cấp một lần cho ...ông, bà (có danh sách kèm theo) là thanh niên xung phong đã hoàn thành nhiệm vụ trở về địa phương.

Tổng số tiền .................. đồng

(Bằng chữ: ......................................đồng)

Điều 2. Quyết định này có hiệu lực thi hành kể từ ngày ký.

Điều 3. Giám đốc Sở Nội vụ, Sở Lao động - Thương binh và Xã hội, Sở Tài chính, Thủ trưởng các cơ quan, đơn vị có liên quan và các ông (bà) có tên trong danh sách chịu trách nhiệm thi hành Quyết định này./.

| Nơi nhận: - Như Điều 2; - Lưu: VT, SNV | TM. ỦY BAN NHÂN DÂN CHỦ TỊCH (Ký, họ và tên, đóng dấu) |
|---|---|

Ghi chú: Trường hợp số đối tượng được hưởng dưới 5 người thì không cần lập biểu danh sách kèm theo; khi đó, nội dung Điều 1 Quyết định cần ghi cụ thể: họ và tên đối tượng được hưởng, Số định danh cá nhân/Chứng minh nhân dân số... cấp ngày... tháng ... năm ... nơi cấp..., số năm được hưởng, mức trợ cấp.