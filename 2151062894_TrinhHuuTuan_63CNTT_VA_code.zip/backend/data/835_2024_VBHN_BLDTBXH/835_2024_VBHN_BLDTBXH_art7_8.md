# 835_2024_VBHN_BLDTBXH_art7_8

Điều 7. Tổ chức thực hiện

1. Ủy ban nhân dân cấp tỉnh có trách nhiệm bố trí ngân sách địa phương để thực hiện chế độ trợ cấp hàng tháng theo quy định tại Thông tư này; chỉ đạo thực hiện và kiểm tra, giám sát việc thực hiện chế độ trợ cấp đối với TNXP đã hoàn thành nhiệm vụ trong kháng chiến.

2. Bộ Lao động - Thương binh và Xã hội: Trong thời gian không quá 05 ngày làm việc kể từ khi nhận được công văn đề nghị bổ sung dự toán kinh phí chi chế độ trợ cấp một lần của địa phương có trách nhiệm bổ sung dự toán để địa phương thực hiện chi trả trợ cấp và thanh quyết toán theo quy định.

3. Bộ Nội vụ có trách nhiệm chỉ đạo Sở Nội vụ chủ động phối hợp với các Sở, ngành liên quan giải quyết kịp thời những vướng mắc phát sinh trong việc lập hồ sơ, xác nhận hồ sơ, xét duyệt và thẩm định hồ sơ trình Chủ tịch Ủy ban nhân dân cấp tỉnh quyết định theo quy định tại Thông tư này.

4. Bộ Tài chính có trách nhiệm bố trí ngân sách nhà nước để thực hiện chế độ trợ cấp một lần cho TNXP theo quy định tại Thông tư này.

5. Đề nghị Hội Cựu TNXP Việt Nam: Tổ chức tuyên truyền phổ biến về chế độ, chính sách đối với TNXP theo quy định tại Thông tư này; hướng dẫn Hội cựu TNXP các cấp phối hợp với cơ quan, đoàn thể địa phương thực hiện việc xác nhận, cam kết đúng đối tượng được hưởng chính sách tránh hiện tượng man khai, lợi dụng để hưởng chế độ chính sách.

Điều 8. Hiệu lực thi hành3

Thông tư này có hiệu lực kể từ ngày 01 tháng 6 năm 2012.

Thông tư này bãi bỏ Thông tư Liên tịch số 17/2003/TTLT-LĐTBXH- TWĐTNCSHCM ngày 09/6/2003 và Thông tư Liên tịch số 26/2007/TTLT- LĐTBXH-TWĐTNCSHCM ngày 21/11/2007 của Bộ Lao động - Thương binh và Xã hội - Trung ương Đoàn Thanh niên Cộng sản Hồ Chí Minh.

Trong quá trình thực hiện nếu có vướng mắc đề nghị phản ánh kịp thời về Bộ Lao động - Thương binh và Xã hội, Bộ Nội vụ và Bộ Tài chính để xem xét, giải quyết./.

| Nơi nhận: - VPCP (để đăng công báo); - Bộ trưởng (để báo cáo); - Cổng Thông tin điện tử Chính phủ; - Trang Thông tin điện tử của Bộ (để đăng tải); - Lưu: VT, Cục NCC. | XÁC THỰC VĂN BẢN HỢP NHẤT KT. BỘ TRƯỞNG THỨ TRƯỞNG Nguyễn Bá Hoan |