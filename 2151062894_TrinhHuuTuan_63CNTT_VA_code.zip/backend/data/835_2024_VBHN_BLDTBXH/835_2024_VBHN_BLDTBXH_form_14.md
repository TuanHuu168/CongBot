# 835_2024_VBHN_BLDTBXH_form_14

Mẫu số 1424

| UBND TỈNH, (TP)...... ------- |  |
|---|---|

DANH SÁCH THANH NIÊN XUNG PHONG ĐƯỢC HƯỞNG CHẾ ĐỘ TRỢ CẤP HÀNG THÁNG (Kèm theo Quyết định số .../QĐ-UBND ngày.../.../.... của UBND tỉnh ....)

Đơn vị: Đồng/tháng

| Số TT | Họ và tên | Ngày, tháng, năm sinh | Số định danh cá nhân/Chứng minh nhân dân, cấp ngày tháng năm, nơi cấp | Mức trợ cấp khởi điểm | Ghi chú |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  | Cộng |  |  |  |  |

| NGƯỜI LẬP (Ký, ghi rõ họ và tên) | ........, ngày ... tháng... năm ...... TM. ỦY BAN NHÂN DÂN CHỦ TỊCH (Ký, họ và tên, đóng dấu) |
|---|---|