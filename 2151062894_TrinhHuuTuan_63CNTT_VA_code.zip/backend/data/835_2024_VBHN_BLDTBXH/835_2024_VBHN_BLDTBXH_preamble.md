# 835_2024_VBHN_BLDTBXH_preamble


| BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 835/VBHN-BLĐTBXH | Hà Nội, ngày 05 tháng 3 năm 2024 |

THÔNG TƯ LIÊN TỊCH

HƯỚNG DẪN THỰC HIỆN CHẾ ĐỘ TRỢ CẤP ĐỐI VỚI THANH NIÊN XUNG PHONG ĐÃ HOÀN THÀNH NHIỆM VỤ TRONG KHÁNG CHIẾN THEO QUYẾT ĐỊNH SỐ 40/2011/QĐ-TTG NGÀY 27 THÁNG 7 NĂM 2011 CỦA THỦ TƯỚNG CHÍNH PHỦ

Thông tư liên tịch số 08/2012/TTLT-BLĐTBXH-BNV-BTC ngày 16 tháng 04 năm 2012 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội, Bộ trưởng Bộ Nội vụ, Bộ trưởng Bộ Tài chính hướng dẫn thực hiện chế độ trợ cấp đối với thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến theo Quyết định số 40/2011/QĐ-TTg ngày 27 tháng 7 năm 2011 của Thủ tướng Chính phủ, có hiệu lực kể từ ngày 01 tháng 6 năm 2012, được sửa đổi, bổ sung bởi:

Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

Căn cứ Nghị định số 186/2007/NĐ-CP ngày 25/12/2007 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Lao động - Thương binh và Xã hội;

Căn cứ Nghị định số 48/2008/NĐ-CP ngày 17/4/2008 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Nội vụ;

Căn cứ Nghị định số 118/2008/NĐ-CP ngày 27/11/2008 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Tài chính;

Căn cứ Quyết định số 40/2011/QĐ-TTg ngày 27/7/2011 của Thủ tướng Chính phủ quy định về chế độ đối với thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến,

Bộ trưởng Bộ Lao động - Thương binh và Xã hội, Bộ trưởng Bộ Nội vụ, Bộ trưởng Bộ Tài chính ban hành Thông tư liên tịch hướng dẫn thực hiện chế độ trợ cấp đối với thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến theo Quyết định số 40/2011/QĐ-TTg ngày 27/7/2011 của Thủ tướng Chính phủ.1