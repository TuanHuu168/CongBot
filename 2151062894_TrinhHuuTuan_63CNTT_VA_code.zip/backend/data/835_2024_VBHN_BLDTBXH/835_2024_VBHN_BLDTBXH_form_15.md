# 835_2024_VBHN_BLDTBXH_form_15

Mẫu số 1525

| UBND TỈNH, (TP)...... SỞ LAO ĐỘNG-TBXH ------- |  |
|---|---|

TỔNG HỢP DANH SÁCH THANH NIÊN XUNG PHONG ĐÃ ĐƯỢC GIẢI QUYẾT CHẾ ĐỘ TRỢ CẤP MỘT LẦN (Kèm theo công văn số ...... ngày.../.../.... của Sở LĐTBXH ....)

| Số TT | Họ và tên | Ngày, tháng, năm sinh | Số định danh cá nhân/Chứng minh nhân dân, cấp ngày tháng năm, nơi cấp | Quan hệ với TNXP | Quyết định của UBND tỉnh | Số năm được hưởng | Số tiền trợ cấp một lần |  |
|---|---|---|---|---|---|---|---|---|
| Số quyết định | Ngày, tháng, năm |  |  |  |  |  |  |  |
| (1) | (2) | (3) | (4) | (5) | (6) | (7) | (8) | (9) |
| I | Huyện A |  |  |  |  |  |  |  |
| 1 |  |  |  |  |  |  |  |  |
| 2 |  |  |  |  |  |  |  |  |
| 3 |  |  |  |  |  |  |  |  |
| II | Huyện B |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
| III | Huyện C |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  | Cộng |  |  |  |  |  |  |

Tổng số đối tượng được hưởng: ... người, trong đó đã từ trần..... người.

Tổng số tiền: ...... đồng (Bằng chữ..........)

| NGƯỜI LẬP (Ký, ghi rõ họ và tên) | ........, ngày ... tháng... năm ...... GIÁM ĐỐC (Ký, họ và tên, đóng dấu) |
|---|---|

Ghi chú:

- Trường hợp TNXP còn sống thì bỏ chỉ tiêu ở cột (5)

- Trường hợp TNXP đã từ trần thì bỏ chỉ tiêu ở cột (8)