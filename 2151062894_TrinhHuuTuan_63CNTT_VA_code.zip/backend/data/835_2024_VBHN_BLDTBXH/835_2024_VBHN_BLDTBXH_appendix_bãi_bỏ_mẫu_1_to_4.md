# 835_2024_VBHN_BLDTBXH_appendix_bãi_bỏ_mẫu_1_to_4

Mẫu số 1A4 (được bãi bỏ)

Mẫu số 1B5 (được bãi bỏ)

Mẫu số 1C6 (được bãi bỏ)

Mẫu số 027 (được bãi bỏ)

Mẫu số 3A8 (được bãi bỏ)

Mẫu số 3B9 (được bãi bỏ)

Mẫu số 3C10 (được bãi bỏ)

Mẫu số 4A11 (được bãi bỏ)

Mẫu số 4B12 (được bãi bỏ)

Mẫu số 4C13 (được bãi bỏ)

Mẫu số 0514 (được bãi bỏ)