# 836_2024_VBHN_BLDTBXH_art1

Điều 1. Đối tượng

1. Đối tượng áp dụng

Đối tượng được hưởng chính sách theo Điều 1 Quyết định số 170/2008/QĐ-TTg ngày 18 tháng 12 năm 2008 của Thủ tướng Chính phủ (gọi tắt là Quyết định số 170/2008/QĐ-TTg) là người tham gia lực lượng thanh niên xung phong tập trung trong kháng chiến chống Pháp (gọi tắt là thanh niên xung phong) bao gồm cả thanh niên xung phong tham gia khắc phục hậu quả chiến tranh đến hết năm 1958.

2. Đối tượng không áp dụng

a) Thanh niên xung phong phạm tội xâm phạm an ninh quốc gia hoặc phạm tội khác bị phạt tù chung thân hoặc đang trong thời gian chấp hành hình phạt tù.

b) Thanh niên xung phong không hoàn thành nhiệm vụ.

c) Thanh niên xung phong thuộc đối tượng tham gia bảo hiểm y tế bắt buộc hoặc đã được Nhà nước mua bảo hiểm y tế thì không thuộc diện áp dụng chế độ bảo hiểm y tế quy định tại Thông tư này.

d) Thanh niên xung phong thuộc đối tượng được hưởng mai táng phí theo quy định hiện hành thì không thuộc diện áp dụng trợ cấp mai táng quy định tại Thông tư này.

e) Thanh niên xung phong đã xuất cảnh bất hợp pháp hoặc định cư ở nước ngoài bất hợp pháp.