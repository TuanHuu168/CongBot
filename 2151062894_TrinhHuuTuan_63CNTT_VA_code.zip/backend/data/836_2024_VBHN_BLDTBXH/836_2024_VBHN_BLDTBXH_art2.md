# 836_2024_VBHN_BLDTBXH_art2

Điều 2. Chế độ

1. Chế độ bảo hiểm y tế

a) Thanh niên xung phong được Nhà nước mua bảo hiểm y tế như đối với thanh niên xung phong chống Mỹ cứu nước theo Quyết định số 290/2005/QĐ- TTg ngày 08 tháng 11 năm 2005 của Thủ tướng Chính phủ.

b) Quyền lợi của người được hưởng chế độ bảo hiểm y tế thực hiện theo quy định hiện hành.

2. Trợ cấp mai táng

a) Thanh niên xung phong chết, người hoặc tổ chức lo mai táng được nhận trợ cấp mai táng như các đối tượng tham gia bảo hiểm xã hội bắt buộc do Luật Bảo hiểm xã hội quy định.

b) Trường hợp đối tượng chế từ ngày Quyết định số 170/2008/QĐ-TTg có hiệu lực thi hành đến ngày Thông tư này có hiệu lực thi hành, nếu chưa được hưởng chế độ mai táng phí thì người hoặc tổ chức lo mai táng cho đối tượng được hưởng trợ cấp mai táng theo quy định tại Thông tư này.