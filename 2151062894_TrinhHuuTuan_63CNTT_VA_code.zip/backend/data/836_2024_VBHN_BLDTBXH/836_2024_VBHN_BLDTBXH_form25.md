# 836_2024_VBHN_BLDTBXH_form25

MẪU SỐ 25[14]

| UBND TỈNH, THÀNH PHỐ....... SỞ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------
|---|---|
| Số: /...... | ........, ngày......tháng.....năm......

QUYẾT ĐỊNH

Về việc giải quyết trợ cấp mai táng

GIÁM ĐỐC SỞ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI

Căn cứ Quyết định số 170/2008/QĐ-TTg ngày 18 tháng 12 năm 2008 của Thủ tướng Chính phủ về chế độ bảo hiểm y tế và trợ cấp mai táng đối với thanh niên xung phong thời kỳ kháng chiến chống Pháp;

Căn cứ Thông tư số 24/2009/TT-BLĐTBXH ngày 10 tháng 7 năm 2009 của Bộ Lao động - Thương binh và Xã hội;

Xét đề nghị của Trưởng phòng Người có công,

QUYẾT ĐỊNH

Điều 1. Trợ cấp mai táng một lần với số tiền là:...............................

(bằng chữ:...............................................................) đối với:

Họ tên cá nhân (hoặc tên tổ chức):...............................................

Ngày, tháng, năm sinh:..............................................................

Số định danh cá nhân/Chứng minh nhân dân:...............................cấp ngày......tháng......năm............nơi cấp...............................................

Quan hệ với thanh niên xung phong đã chết:.....................................

Họ và tên TNXP đã chết:.........................................................

Số định danh cá nhân/Chứng minh nhân dân:...............................cấp ngày......tháng......năm............nơi cấp........................................

Được công nhận là thanh niên xung phong thời kỳ kháng chiến chống Pháp theo giấy tờ sau:.....................................................................

Chết ngày ....tháng.....năm.....

Theo Giấy khai tử số: .........., ngày......tháng.....năm...... của Ủy ban nhân dân cấp xã: ...........................................................................

Điều 2. Các ông (bà): Trưởng phòng Người có công, Phòng Kế hoạch Tài chính, Phòng Lao động - Thương binh và Xã hội........................ và ông (bà)..............................chịu trách nhiệm thi hành Quyết định này./.

| Nơi nhận: - Như Điều 2; - Cục NCC- Bộ LĐTBXH; - Lưu: VT | GIÁM ĐỐC (Ký tên, đóng dấu) |
|---|---|

[14] Mẫu này được ban hành theo quy định tại Điều 4 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.