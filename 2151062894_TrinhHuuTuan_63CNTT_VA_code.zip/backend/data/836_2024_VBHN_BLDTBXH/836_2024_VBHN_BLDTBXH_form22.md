# 836_2024_VBHN_BLDTBXH_form22

MẪU SỐ 22[11]

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------

BIÊN BẢN XÁC NHẬN VÀ ĐỀ NGHỊ GIẢI QUYẾT CHẾ ĐỘ BẢO HIỂM Y TẾ ĐỐI VỚI THANH NIÊN XUNG PHONG

Hôm nay, ngày...... tháng .... năm ........., đại diện Đảng ủy, Ủy ban nhân dân, các tổ chức đoàn thể và nhân dân xã (phường):.................................... bao gồm (ghi rõ họ tên và chức danh):

.....................................................................................................

......................................................................................................

......................................................................................................

......................................................................................................

.....................................................................................................

đã họp để xem xét, đề nghị giải quyết chế độ bảo hiểm y tế đối với:

Ông (bà) ..................................................................................

Ngày, tháng, năm sinh:.................................................................

Số định danh cá nhân/Chứng minh nhân dân:.................................cấp ngày......tháng......năm............nơi cấp...................................................

Ngày tham gia thanh niên xung phong: ..............................................

Ngày hoàn thành nhiệm vụ trở về gia đình: ...........................................

Thuộc đơn vị thanh niên xung phong ...............................................

Tham gia thanh niên xung phong thời kỳ kháng chiến, đã hoàn thành nhiệm vụ trở về gia đình.

Đề nghị các cơ quan chức năng xem xét, giải quyết chế độ bảo hiểm y tế đối với ông (bà):............................................. theo quy định./.

| Đại diện | Đại diện | Đại diện | Đại diện |
|---|---|---|---|
| Mặt trận Tổ quốc | TNXP | Đảng ủy | UBND xã |

[11] Mẫu này được ban hành theo quy định tại Điều 4 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.