# 836_2024_VBHN_BLDTBXH_form21

MẪU SỐ 21[10]

| TỈNH ĐOÀN, THÀNH ĐOÀN -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------
|---|---|
| Số: /...... | ........, ngày......tháng.....năm......

GIẤY CHỨNG NHẬN

Thanh niên xung phong hoàn thành nhiệm vụ trong kháng chiến chống Pháp

BAN THƯỜNG VỤ TỈNH (THÀNH) ĐOÀN.............. CHỨNG NHẬN

Ông (bà):.................................................................................

Ngày, tháng, năm sinh:.................................................................

Số định danh cá nhân/Chứng minh nhân dân:..................................cấp ngày......tháng......năm............nơi cấp...................................................

Tham gia thanh niên xung phong ngày......tháng......năm ........

Đã hoàn thành nhiệm vụ trở về gia đình ngày...... tháng...... năm .........

Thuộc đơn vị thanh niên xung phong:.............................................

Đề nghị các cơ quan chức năng xem xét, giải quyết chế độ, chính sách đối với thanh niên xung phong theo quy định./.

| ......., ngày .....tháng.....năm....... Xác nhận của Hội (Ban Liên lạc) Cựu TNXP cấp tỉnh Chủ tịch (Ký tên, đóng dấu) | ......., ngày...... tháng ...... năm ......... TM. BAN THƯỜNG VỤ Bí thư (Ký tên, đóng dấu) |
|---|---|

[10] Mẫu này được ban hành theo quy định tại Điều 4 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.