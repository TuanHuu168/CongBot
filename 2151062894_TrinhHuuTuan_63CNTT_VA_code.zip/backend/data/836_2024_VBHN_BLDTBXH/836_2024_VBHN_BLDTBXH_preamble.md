# 836_2024_VBHN_BLDTBXH_preamble


| BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------
|---|---|
| Số: 836/VBHN-BLĐTBXH | Hà Nội, ngày 05 tháng 3 năm 2024

THÔNG TƯ

HƯỚNG DẪN THỰC HIỆN QUYẾT ĐỊNH SỐ 170/2008/QĐ-TTG NGÀY 18 THÁNG 12 NĂM 2008 CỦA THỦ TƯỚNG CHÍNH PHỦ VỀ CHẾ ĐỘ BẢO HIỂM Y TẾ VÀ TRỢ CẤP MAI TÁNG ĐỐI VỚI THANH NIÊN XUNG PHONG THỜI KỲ KHÁNG CHIẾN CHỐNG PHÁP

Thông tư số 24/2009/TT-BLĐTBXH ngày 10 tháng 07 năm 2009 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội hướng dẫn thực hiện Quyết định số 170/2008/QĐ-TTg ngày 18 tháng 12 năm 2008 của Thủ tướng Chính phủ về chế độ bảo hiểm y tế và trợ cấp mai táng đối với thanh niên xung phong thời kỳ kháng chiến chống Pháp, có hiệu lực kể từ ngày 24 tháng 8 năm 2009 được sửa đổi, bổ sung bởi:

Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động - Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

Căn cứ Quyết định số 170/2008/QĐ-TTg ngày 18 tháng 12 năm 2008 của Thủ tướng Chính phủ về chế độ bảo hiểm y tế và trợ cấp mai táng đối với thanh niên xung phong thời kỳ kháng chiến chống Pháp;

Bộ Lao động - Thương binh và Xã hội hướng dẫn việc lập hồ sơ, thủ tục xác nhận đối tượng để thực hiện chế độ bảo hiểm y tế và trợ cấp mai táng đối với thanh niên xung phong thời kỳ kháng chiến chống Pháp như sau:[1]