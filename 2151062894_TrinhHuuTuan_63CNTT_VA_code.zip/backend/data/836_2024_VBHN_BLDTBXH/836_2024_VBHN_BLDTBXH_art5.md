# 836_2024_VBHN_BLDTBXH_art5

Điều 5. Tổ chức thực hiện[2]

1. Sở Lao động - Thương binh và Xã hội:

- Tiến hành mua bảo hiểm y tế. Tổ chức chi trả trợ cấp mai táng đối với người hoặc tổ chức lo mai táng.

- Chủ trì phối hợp với Tỉnh, Thành đoàn: Hội (hoặc Ban Liên lạc) Cựu Thanh niên xung phong tổ chức tuyên truyền rộng rãi nội dung Thông tư này.

2. Thông tư này có hiệu lực thi hành sau 45 ngày, kể từ ngày ký ban hành. Trong quá trình triển khai thực hiện, nếu có vướng mắc, đề nghị các cơ quan, địa phương phản ánh về Bộ Lao động - Thương binh và Xã hội để được hướng dẫn giải quyết./.

| Nơi nhận: - VPCP (để đăng công báo); - Bộ trưởng (để báo cáo); - Cổng Thông tin điện tử Chính phủ; - Trang Thông tin điện tử của Bộ (để đăng tải); - Lưu: VT, Cục NCC. | XÁC THỰC VĂN BẢN HỢP NHẤT KT. BỘ TRƯỞNG THỨ TRƯỞNG Nguyễn Bá Hoan |
|---|---|

[1] Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội có căn cứ ban hành như sau:

“Căn cứ Luật Cư trú ngày 13 tháng 11 năm 2020;

Căn cứ Luật Ban hành văn bản quy phạm pháp luật ngày 22 tháng 6 năm 2015 và Luật sửa đổi, bổ sung một số điều của Luật Ban hành văn bản quy phạm pháp luật ngày 18 tháng 6 năm 2020;

Căn cứ Nghị định số 62/2022/NĐ-CP ngày 12 tháng 9 năm 2022 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Lao động - Thương binh và Xã hội;

Căn cứ Nghị định số 104/2022/NĐ-CP ngày 21 tháng 12 năm 2022 của Chính phủ sửa đổi, bổ sung một số điều của các nghị định liên quan đến việc nộp, xuất trình sổ hộ khẩu, sổ tạm trú giấy khi thực hiện thủ tục hành chính, cung cấp dịch vụ công;

Theo đề nghị của Vụ trưởng Vụ Pháp chế;

Bộ trưởng Bộ Lao động - Thương binh và Xã hội ban hành Thông tư sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch do Bộ trưởng Bộ Lao động - Thương binh và Xã hội ban hành, liên tịch ban hành.”.

[2] Điều 5 Thông tư số 08/2023/TT-BLĐTBXH sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023 quy định như sau:

“1. Thông tư này có hiệu lực thi hành kể từ ngày 12 tháng 10 năm 2023.

2. Các Mẫu giấy tờ là thành phần hồ sơ thực hiện thủ tục hành chính đã được tiếp nhận trước ngày Thông tư này có hiệu lực mà chưa giải quyết xong thì tiếp tục được giải quyết theo quy định tại Thông tư, Thông tư liên tịch chưa được sửa đổi, bổ sung hoặc bãi bỏ bởi Thông tư này.

3. Vụ trưởng Vụ Pháp chế, Thủ trưởng các đơn vị quản lý nhà nước thuộc Bộ Lao động - Thương binh và Xã hội và các cơ quan, tổ chức, cá nhân có liên quan chịu trách nhiệm thi hành Thông tư này.

Trong quá trình thực hiện, nếu có vướng mắc, đề nghị kịp thời phản ánh về Bộ Lao động - Thương binh và Xã hội để nghiên cứu, giải quyết./.”.