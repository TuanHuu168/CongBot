# 836_2024_VBHN_BLDTBXH_art4

Điều 4. Hồ sơ giải quyết chế độ mai táng phí

1. Hồ sơ

a) Thanh niên xung phong đang hưởng bảo hiểm y tế theo Quyết định số 170/2008/QĐ-TTg chết:

- Giấy khai tử do Ủy ban nhân dân cấp xã cấp.

- Bản khai của người hoặc tổ chức lo mai táng đối với thanh niên xung phong đã chết (Mẫu số 04-A).

b) Thanh niên xung phong chết từ ngày Quyết định số 170/2008/QĐ-TTg đến ngày Thông tư có hiệu lực thi hành và thanh niên xung phong không hưởng bảo hiểm y tế theo Quyết định số 170/2008/QĐ-TTg (Mẫu số 04-B).

- Giấy khai tử do Ủy ban nhân dân cấp xã cấp.

- Bản khai của người hoặc tổ chức lo mai táng đối với thanh niên xung phong đã chết, kèm một trong những giấy tờ xác nhận là thanh niên xung phong quy định tại điểm a, khoản 1, Điều 3 Thông tư này.

2. Trách nhiệm lập hồ sơ

a) Thân nhân lập bản khai thanh niên xung phong từ trần kèm theo giấy khai tử.

b) Ủy ban nhân dân cấp xã xác nhận vào bản khai của từng người; chuyển bản khai kèm giấy khai tử và một trong những giấy tờ xác nhận là thanh niên xung phong quy định tại điểm a, khoản 1, Điều 3 Thông tư này về Phòng Lao động - Thương binh và Xã hội.

c) Phòng Lao động - Thương binh và Xã hội lập danh sách kèm theo các giấy tờ chuyển Sở Lao động - Thương binh và Xã hội.

d) Sở Lao động - Thương binh và Xã hội:

- Ghép hồ sơ thanh niên xung phong đang quản lý cấp thẻ bảo hiểm y tế (nếu có) với bản khai, giấy khai tử để hoàn chỉnh hồ sơ giải quyết mai táng phí.

- Giám đốc Sở Lao động - Thương binh và Xã hội ra quyết định trợ cấp mai táng (Mẫu số 05)