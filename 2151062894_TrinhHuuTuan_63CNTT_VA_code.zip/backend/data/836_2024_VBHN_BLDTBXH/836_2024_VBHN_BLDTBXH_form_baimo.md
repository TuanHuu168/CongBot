# 836_2024_VBHN_BLDTBXH_form_baimo

MẪU SỐ 01[3] (được bãi bỏ)

MẪU SỐ 02[4] (được bãi bỏ)

MẪU SỐ 03[5] (được bãi bỏ)

MẪU SỐ 04-A[6] (được bãi bỏ)

MẪU SỐ 04-B[7] (được bãi bỏ)

MẪU SỐ 05[8] (được bãi bỏ)

[3] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

[4] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

[5] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

[6] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

[7] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.

[8] Mẫu này được bãi bỏ theo quy định tại khoản 2 Điều 2 của Thông tư số 08/2023/TT-BLĐTBXH ngày 29 tháng 8 năm 2023 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội sửa đổi, bổ sung, bãi bỏ một số điều của các Thông tư, Thông tư liên tịch có quy định liên quan đến việc nộp, xuất trình sổ hộ khẩu giấy, sổ tạm trú giấy hoặc giấy tờ có yêu cầu xác nhận nơi cư trú khi thực hiện thủ tục hành chính thuộc lĩnh vực quản lý nhà nước của Bộ Lao động - Thương binh và Xã hội, có hiệu lực kể từ ngày 12 tháng 10 năm 2023.