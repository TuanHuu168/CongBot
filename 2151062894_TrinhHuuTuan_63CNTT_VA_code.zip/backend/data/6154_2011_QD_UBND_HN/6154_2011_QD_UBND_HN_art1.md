# 6154_2011_QD_UBND_HN_art1

Điều 1. Thực hiện chế độ điều dưỡng luân phiên 02 năm một lần đối với người có công với cách mạng trên địa bàn thành phố Hà Nội:

1. Đối tượng: Người có công với cách mạng (được quy định tại khoản 2 điều 3 Mục II Thông tư liên tịch số 25/2010/TTLT-BLĐTBXH-BTC-BYT ngày 11/9/2010 của Liên Bộ: Lao động Thương binh và Xã hội, Tài chính, Y tế về việc sửa đổi, bổ sung Thông tư liên tịch số 17/2006/TTLT-BLĐTBXH-BTC-BYT ngày 21/11/2006 và thay thế Thông tư liên tịch số 06/2007/TTLT-BLĐTBXH-BTC-BYT ngày 12/4/2007 của liên Bộ Lao động Thương binh và Xã hội - Tài chính - Y tế hướng dẫn chế độ chăm sóc sức khỏe đối với người có công với cách mạng)

2. Hình thức điều dưỡng, mức chi điều dưỡng: Thực hiện theo Thông tư liên tịch số 25/2010/TTLT-BLĐTBXH-BTC-BYT ngày 11/9/2010 của Liên Bộ Lao động Thương binh và Xã hội, Tài chính, Y tế về việc sửa đổi, bổ sung Thông tư liên tịch số 17/2006/TTLT-BLĐTBXH-BTC-BYT ngày 21/11/2006 và thay thế Thông tư liên tịch số 06/2007/TTLT-BLĐTBXH-BTC-BYT ngày 12/4/2007 của liên Bộ: Lao động Thương binh và Xã hội - Tài chính - Y tế hướng dẫn chế độ chăm sóc sức khỏe đối với người có công với cách mạng và Quyết định của Ủy ban nhân dân Thành phố.

3. Thời gian thực hiện: Từ ngày 01/01/2012.

4. Nguồn kinh phí: Ngân sách Thành phố đảm bảo và bố trí trong dự toán giao hàng năm cho Sở Lao động Thương binh và Xã hội.