# 6154_2011_QD_UBND_HN_preamble

Về việc thực hiện chế độ điều dưỡng luân phiên đối với người có công với cách mạng trên địa bàn thành phố Hà Nội

| ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 6154/QĐ-UBND | Hà Nội, ngày 30 tháng 12 năm 2011 |

QUYẾT ĐỊNH

VỀ VIỆC THỰC HIỆN CHẾ ĐỘ ĐIỀU DƯỠNG LUÂN PHIÊN ĐỐI VỚI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG TRÊN ĐỊA BÀN THÀNH PHỐ HÀ NỘI

ỦY BAN NHÂN DÂN THÀNH PHỐ HÀ NỘI

Căn cứ Luật Tổ chức Hội đồng nhân dân và Ủy ban nhân dân ngày 26/11/2003;

Căn cứ Luật Ngân sách nhà nước ngày 16/12/2002;

Căn cứ Thông tư liên tịch số 25/2010/TTLT-BLĐTBXH-BTC-BYT ngày 11/9/2010 của Liên Bộ: Lao động Thương binh và Xã hội, Tài chính, Y tế về việc sửa đổi, bổ sung Thông tư liên tịch số: 17/2006/TTLT-BLĐTBXH-BTC-BYT ngày 21/11/2006 và thay thế Thông tư liên tịch số 06/2007/TTLT-BLĐTBXH-BTC-BYT ngày 12/4/2007 của liên Bộ: Lao động Thương binh và Xã hội - Tài chính - Y tế hướng dẫn chế độ chăm sóc sức khỏe đối với người có công với cách mạng;

Căn cứ Nghị quyết số 08/2011/NQ-HĐND ngày 9/12/2011 của Hội đồng nhân dân thành phố Hà Nội về dự toán ngân sách và phân bổ dự toán ngân sách thành phố Hà Nội năm 2012;

Xét đề nghị của Sở Tài chính tại Công văn số 6144/STC-HCSN ngày 27/12/2011,

QUYẾT ĐỊNH: