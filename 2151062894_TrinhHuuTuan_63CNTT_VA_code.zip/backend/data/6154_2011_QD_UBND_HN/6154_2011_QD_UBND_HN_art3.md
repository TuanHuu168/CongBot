# 6154_2011_QD_UBND_HN_art3

Điều 3. Chánh Văn phòng Ủy ban nhân dân Thành phố; Giám đốc các Sở: Lao động Thương binh và Xã hội, Tài chính, Y tế; Giám đốc kho bạc Nhà nước Hà Nội và Chủ tịch Ủy ban nhân dân các quận, huyện, thị xã chịu trách nhiệm thi hành Quyết định này./.

| Nơi nhận: - Như Điều 3; - Bộ LĐTB&XH; (để báo cáo) - TT Thành ủy; TT HĐND TP; (để báo cáo) - Đ/c Chủ tịch UBND TP; (để báo cáo) - Các đ/c PCT UBND TP; - Các đ/c PVP: Lý Văn Giao, Đỗ Đình Hồng; - Các phòng: LĐCSXH, TH, KT; - Lưu: VT. | TM. ỦY BAN NHÂN DÂN KT. CHỦ TỊCH PHÓ CHỦ TỊCH Nguyễn Huy Tưởng |
|---|---|