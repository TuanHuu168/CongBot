# 6154_2011_QD_UBND_HN_art2

Điều 2. Sở Lao động Thương binh và Xã hội có trách nhiệm xây dựng kế hoạch điều dưỡng người có công trong kế hoạch dự toán ngân sách hàng năm; chỉ đạo các trung tâm nuôi dưỡng và điều dưỡng người có công của Thành phố triển khai tổ chức thực hiện điều dưỡng và chịu trách nhiệm thanh quyết toán theo quy định của Luật Ngân sách nhà nước.