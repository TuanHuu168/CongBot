# 62_2011_QD_TTg_art5

Điều 5. Chế độ trợ cấp

1. Chế độ trợ cấp hàng tháng được quy định như sau:

a) Đối tượng quy định tại điểm a khoản 1 Điều 2 Quyết định này có từ đủ 15 năm đến dưới 20 năm công tác được tính hưởng theo quy định tại Điều 4 Quyết định này (bao gồm cả số đối tượng đã phục viên, xuất ngũ, thôi việc hiện đang công tác ở xã có tham gia bảo hiểm xã hội bắt buộc nhưng khi tính nối thời gian phục vụ trong quân đội, công an, cơ yếu với thời gian công tác ở xã mà không đủ điều kiện hưởng chế độ hưu trí theo quy định) được hưởng chế độ trợ cấp hàng tháng theo số năm công tác.

Mức trợ cấp là 925.000 đồng/tháng, nếu đủ 15 năm; sau đó cứ thêm một năm (đủ 12 tháng) được tính thêm 5% của mức trợ cấp nêu trên.

Khi Chính phủ điều chỉnh lương hưu, trợ cấp bảo hiểm xã hội và trợ cấp hàng tháng thì mức trợ cấp được điều chỉnh tương ứng.

b) Đối tượng được hưởng chế độ trợ cấp hàng tháng từ trần thì thôi hưởng trợ cấp từ tháng tiếp theo; thân nhân của đối tượng từ trần được hưởng trợ cấp một lần bằng 03 tháng trợ cấp hiện hưởng của đối tượng từ trần.

2. Chế độ trợ cấp một lần được quy định như sau:

a) Đối tượng quy định tại điểm a khoản 1 Điều 2 Quyết định này có dưới 15 năm công tác được tính hưởng theo quy định tại Điều 4 Quyết định này (bao gồm cả đối tượng đã phục viên, xuất ngũ, thôi việc hiện đang công tác ở xã có tham gia bảo hiểm xã hội bắt buộc hoặc đối tượng có dưới 20 năm công tác trong quân đội, công an, cơ yếu sau đó tham gia công tác ở xã đã nghỉ việc hiện đang hưởng chế độ hưu trí nhưng khi thôi công tác ở xã, thời gian phục vụ trong quân đội, công an, cơ yếu không được cộng nối với thời gian công tác ở xã để tính hưởng chế độ bảo hiểm xã hội) được hưởng chế độ trợ cấp một lần tính theo thời gian công tác.

Mức trợ cấp bằng 2.500.000 đồng, nếu có từ đủ 2 năm công tác thực tế trở xuống; từ năm thứ 3 trở đi cứ mỗi năm được cộng thêm 800.000 đồng.

b) Đối tượng quy định tại điểm b, c, d và đ khoản 1 Điều 2 Quyết định này được hưởng chế độ trợ cấp một lần tính theo thời gian thực tế trực tiếp tham gia chiến tranh bảo vệ Tổ quốc và làm nhiệm vụ quốc tế.

Mức trợ cấp bằng 2.500.000 đồng, nếu có từ đủ 2 năm trực tiếp tham gia chiến tranh bảo vệ Tổ quốc và làm nhiệm vụ quốc tế trở xuống; từ năm thứ 3 trở đi cứ mỗi năm được cộng thêm 800.000 đồng;

c) Đối tượng quy định tại khoản 1 Điều 2 Quyết định này đã từ trần trước ngày Quyết định này có hiệu lực thi hành (bao gồm cả số từ trần khi đang tại ngũ hoặc đang công tác) thì một trong những thân nhân sau đây của đối tượng được hưởng chế độ trợ cấp một lần bằng 3.600.000 đồng: vợ hoặc chồng; con đẻ, con nuôi; bố đẻ, mẹ đẻ hoặc người nuôi dưỡng hợp pháp.