# 62_2011_QD_TTg_preamble


| THỦ TƯỚNG CHÍNH PHỦ ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------
|---|
| Số: 62/2011/QĐ-TTg | Hà Nội, ngày 09 tháng 11 năm 2011

QUYẾT ĐỊNH

VỀ CHẾ ĐỘ, CHÍNH SÁCH ĐỐI VỚI ĐỐI TƯỢNG THAM GIA CHIẾN TRANH BẢO VỆ TỔ QUỐC, LÀM NHIỆM VỤ QUỐC TẾ Ở CĂM-PU-CHI-A, GIÚP BẠN LÀO SAU NGÀY 30 THÁNG 4 NĂM 1975 ĐÃ PHỤC VIÊN, XUẤT NGŨ, THÔI VIỆC

THỦ TƯỚNG CHÍNH PHỦ

Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001;

Xét đề nghị của Bộ trưởng Bộ Quốc phòng,

QUYẾT ĐỊNH