# 02_2020_UBTVQH14_chuong2_muc5_6
Mục 5. ANH HÙNG LỰC LƯỢNG VŨ TRANG NHÂN DÂN, ANH HÙNG LAO ĐỘNG TRONG THỜI KỲ KHÁNG CHIẾN

Điều 20. Điều kiện, tiêu chuẩn Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến

1. Anh hùng Lực lượng vũ trang nhân dân là người được Nhà nước tặng hoặc truy tặng danh hiệu "Anh hùng Lực lượng vũ trang nhân dân" theo quy định của pháp luật.

2. Anh hùng Lao động trong thời kỳ kháng chiến là người được Nhà nước tặng hoặc truy tặng danh hiệu "Anh hùng Lao động" trong thời kỳ kháng chiến vì có thành tích đặc biệt xuất sắc trong lao động, sản xuất phục vụ kháng chiến.

Điều 21. Chế độ ưu đãi đối với Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến

1. Trợ cấp hằng tháng.

2. Bảo hiểm y tế.

3. Điều dưỡng phục hồi sức khỏe hai năm một lần.

4. Chế độ ưu đãi quy định tại các điểm c, d, đ, e, g, h, i và k khoản 2 Điều 5 của Pháp lệnh này.

Điều 22. Chế độ ưu đãi đối với thân nhân của Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến

1. Bảo hiểm y tế đối với cha đẻ, mẹ đẻ, vợ hoặc chồng, con từ đủ 06 tuổi đến chưa đủ 18 tuổi hoặc từ đủ 18 tuổi trở lên nếu còn tiếp tục đi học hoặc bị khuyết tật nặng, khuyết tật đặc biệt nặng.

2. Chế độ ưu đãi quy định tại điểm d và điểm đ khoản 2 Điều 5 của Pháp lệnh này đối với con của Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến.

3. Trợ cấp một lần đối với thân nhân khi Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến được tặng danh hiệu nhưng chết mà chưa được hưởng chế độ ưu đãi hoặc được truy tặng danh hiệu "Anh hùng Lực lượng vũ trang nhân dân", "Anh hùng Lao động" trong thời kỳ kháng chiến.

4. Trợ cấp một lần đối với thân nhân với mức bằng 03 tháng trợ cấp hằng tháng hiện hưởng khi Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến đang hưởng trợ cấp hằng tháng chết.

5. Trợ cấp mai táng đối với người hoặc tổ chức thực hiện mai táng khi Anh hùng Lực lượng vũ trang nhân dân, Anh hùng Lao động trong thời kỳ kháng chiến đang hưởng trợ cấp hằng tháng chết.

Mục 6. THƯƠNG BINH, NGƯỜI HƯỞNG CHÍNH SÁCH NHƯ THƯƠNG BINH

Điều 23. Điều kiện, tiêu chuẩn thương binh, người hưởng chính sách như thương binh

1. Sỹ quan, quân nhân chuyên nghiệp, hạ sỹ quan, binh sỹ trong Quân đội nhân dân và sỹ quan, hạ sỹ quan, chiến sỹ trong Công an nhân dân bị thương có tỷ lệ tổn thương cơ thể từ 21% trở lên thì được cơ quan, đơn vị có thẩm quyền xem xét công nhận là thương binh, cấp "Giấy chứng nhận thương binh" và "Huy hiệu thương binh" khi thuộc một trong các trường hợp sau đây:

a) Chiến đấu hoặc trực tiếp phục vụ chiến đấu để bảo vệ độc lập, chủ quyền, toàn vẹn lãnh thổ, an ninh quốc gia;

b) Làm nhiệm vụ quốc phòng, an ninh trong địa bàn địch chiếm đóng, địa bàn có chiến sự, địa bàn tiếp giáp với vùng địch chiếm đóng;

c) Trực tiếp đấu tranh chính trị, đấu tranh binh vận có tổ chức với địch;

d) Bị địch bắt, tra tấn vẫn không chịu khuất phục, kiên quyết đấu tranh mà để lại thương tích thực thể;

đ) Làm nghĩa vụ quốc tế;

e) Dũng cảm thực hiện công việc cấp bách, nguy hiểm phục vụ quốc phòng, an ninh;

g) Trực tiếp làm nhiệm vụ huấn luyện chiến đấu, diễn tập hoặc làm nhiệm vụ phục vụ quốc phòng, an ninh có tính chất nguy hiểm;

h) Do tai nạn khi đang trực tiếp làm nhiệm vụ quốc phòng, an ninh ở địa bàn biên giới, trên biển, hải đảo có điều kiện đặc biệt khó khăn theo danh mục do Chính phủ quy định;

i) Trực tiếp làm nhiệm vụ đấu tranh chống tội phạm;

k) Đặc biệt dũng cảm cứu người, cứu tài sản của Nhà nước, của Nhân dân hoặc ngăn chặn, bắt giữ người có hành vi phạm tội, là tấm gương có ý nghĩa tôn vinh, giáo dục, lan tỏa rộng rãi trong xã hội.

2. Người không phải là sỹ quan, quân nhân chuyên nghiệp, hạ sỹ quan, binh sỹ trong Quân đội nhân dân và sỹ quan, hạ sỹ quan, chiến sỹ trong Công an nhân dân bị thương có tỷ lệ tổn thương cơ thể từ 21% trở lên thuộc một trong các trường hợp quy định tại khoản 1 Điều này thì được cơ quan, đơn vị có thẩm quyền xem xét công nhận là người hưởng chính sách như thương binh và cấp "Giấy chứng nhận người hưởng chính sách như thương binh".

3. Thương binh loại B là quân nhân, công an nhân dân bị thương có tỷ lệ tổn thương cơ thể từ 21% trở lên trong khi tập luyện, công tác đã được cơ quan, đơn vị có thẩm quyền công nhận trước ngày 31 tháng 12 năm 1993.

4. Thương binh, người hưởng chính sách như thương binh quy định tại khoản 1 và khoản 2 Điều này có vết thương đặc biệt tái phát, vết thương còn sót, vết thương bổ sung được khám và giám định lại tỷ lệ tổn thương cơ thể theo quy định của Chính phủ.

Thương binh loại B quy định tại khoản 3 Điều này có vết thương còn sót, vết thương bổ sung được khám để xác định tỷ lệ tổn thương cơ thể theo quy định của Chính phủ.

5. Chính phủ quy định chi tiết Điều này.