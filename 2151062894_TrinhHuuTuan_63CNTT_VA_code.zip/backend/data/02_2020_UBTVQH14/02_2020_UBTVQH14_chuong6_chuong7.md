# 02_2020_UBTVQH14_chuong6_chuong7
Điều 55. Xử lý vi phạm

1. Người giả mạo giấy tờ để được xem xét công nhận là người có công với cách mạng, hưởng chế độ ưu đãi người có công với cách mạng thì bị thu hồi quyết định công nhận, chấm dứt hưởng chế độ ưu đãi và phải hoàn trả số tiền đã nhận.

2. Người khai báo gian dối giấy tờ để được hưởng thêm chế độ ưu đãi người có công với cách mạng thì bị chấm dứt chế độ ưu đãi được hưởng thêm và phải hoàn trả số tiền đã nhận do khai báo gian dối.

3. Người chứng nhận sai sự thật hoặc làm giả giấy tờ cho người khác để được xem xét công nhận là người có công với cách mạng; người lợi dụng chức vụ, quyền hạn hoặc thiếu trách nhiệm gây thiệt hại đến lợi ích của Nhà nước, quyền lợi của người có công với cách mạng thì phải bồi thường theo quy định của pháp luật.

4. Người vi phạm quy định về quản lý, sử dụng kinh phí bảo đảm thực hiện chính sách, chế độ ưu đãi người có công với cách mạng và thân nhân của người có công với cách mạng; lợi dụng chính sách, chế độ ưu đãi người có công với cách mạng và thân nhân của người có công với cách mạng để trục lợi thì tùy theo tính chất, mức độ vi phạm mà bị xử lý theo quy định của pháp luật.

Chương VII

ĐIỀU KHOẢN THI HÀNH

Điều 56. Bãi bỏ Điều 4 của Pháp lệnh số 01/2018/UBTVQH14

Bãi bỏ Điều 4 của Pháp lệnh số 01/2018/UBTVQH14 về sửa đổi, bổ sung một số điều của 04 pháp lệnh có liên quan đến quy hoạch.

Điều 57. Hiệu lực thi hành

1. Pháp lệnh này có hiệu lực thi hành từ ngày 01 tháng 7 năm 2021.

2. Pháp lệnh số 26/2005/PL-UBTVQH11 và Pháp lệnh số 04/2012/PL-UBTVQH13 hết hiệu lực kể từ ngày Pháp lệnh này có hiệu lực thi hành.

Điều 58. Quy định chuyển tiếp

Kể từ ngày Pháp lệnh này có hiệu lực thi hành:

1. Người hy sinh, người bị thương, người bị bệnh trước ngày 01 tháng 7 năm 2021 nếu không đủ điều kiện, tiêu chuẩn công nhận người có công với cách mạng theo quy định tại Pháp lệnh này thì được áp dụng điều kiện, tiêu chuẩn theo quy định tại Pháp lệnh số 26/2005/PL-UBTVQH11 được sửa đổi, bổ sung một số điều theo Pháp lệnh số 04/2012/PL-UBTVQH13;

2. Người có công với cách mạng là thương binh, người hưởng chính sách như thương binh, bệnh binh, người hoạt động kháng chiến bị nhiễm chất độc hóa học có tỷ lệ tổn thương cơ thể từ 61% trở lên chết trước ngày 01 tháng 7 năm 2021 thì vợ từ đủ 55 tuổi trở lên hoặc chồng từ đủ 60 tuổi trở lên tại thời điểm người có công với cách mạng chết được hưởng trợ cấp tuất; trường hợp vợ chưa đủ 55 tuổi hoặc chồng chưa đủ 60 tuổi tại thời điểm người có công với cách mạng chết thì trợ cấp tuất được thực hiện theo quy định của Chính phủ./.

TM. ỦY BAN THƯỜNG VỤ QUỐC HỘI
CHỦ TỊCH

Nguyễn Thị Kim Ngân