# 55_2023_NĐ_CP_preamble

| CHÍNH PHỦ -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 55/2023/NĐ-CP | Hà Nội, ngày 21 tháng 7 năm 2023 |

NGHỊ ĐỊNH

SỬA ĐỔI, BỔ SUNG MỘT SỐ ĐIỀU CỦA NGHỊ ĐỊNH SỐ 75/2021/NĐ-CP NGÀY 24 THÁNG 7 NĂM 2021 CỦA CHÍNH PHỦ QUY ĐỊNH MỨC HƯỞNG TRỢ CẤP, PHỤ CẤP VÀ CÁC CHẾ ĐỘ ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

Căn cứ Luật Tổ chức Chính phủ ngày 19 tháng 6 năm 2015; Luật sửa đổi, bổ sung một số điều của Luật Tổ chức Chính phủ và Luật Tổ chức chính quyền địa phương ngày 22 tháng 11 năm 2019;

Căn cứ Pháp lệnh Ưu đãi người có công với cách mạng ngày 09 tháng 12 năm 2020;

Theo đề nghị của Bộ trưởng Bộ Lao động - Thương binh và Xã hội;

Chính phủ ban hành Nghị định sửa đổi, bổ sung một số điều của Nghị định số 75/2021/NĐ-CP ngày 24 tháng 7 năm 2021 của Chính phủ quy định mức hưởng trợ cấp, phụ cấp và các chế độ ưu đãi người có công với cách mạng.