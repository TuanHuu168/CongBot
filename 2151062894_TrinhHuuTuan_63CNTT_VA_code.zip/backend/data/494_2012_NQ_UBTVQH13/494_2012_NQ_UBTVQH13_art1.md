# 494_2012_NQ_UBTVQH13_art1

Điều 1.

Tán thành cơ bản nội dung Báo cáo kết quả giám sát của Đoàn giám sát của Ủy ban thường vụ Quốc hội về việc thực hiện chính sách, pháp luật về người có công với cách mạng về những đánh giá kết quả đạt được, những hạn chế, khó khăn, vướng mắc, nguyên nhân và các kiến nghị, đồng thời nhấn mạnh:

Chính sách ưu đãi người có công với cách mạng là chủ trương lớn, nhất quán của Đảng và Nhà nước. Chính phủ, các bộ, ngành liên quan và các địa phương đã ban hành chính sách, pháp luật và tổ chức tốt việc thi hành. Phong trào đền ơn đáp nghĩa, toàn dân tham gia chăm sóc người có công với cách mạng phát triển sâu rộng, góp phần nâng cao nhận thức, trách nhiệm xã hội và trở thành tình cảm, nét đẹp văn hóa của dân tộc. Về cơ bản, chính sách, pháp luật về người có công với cách mạng đã bảo đảm công bằng và tạo sự đồng thuận cao trong xã hội. Đời sống của người có công với cách mạng đã từng bước được cải thiện và ổn định. Tuy nhiên, việc thực hiện chính sách, pháp luật về người có công với cách mạng còn có một số hạn chế, vướng mắc, một bộ phận người có công với cách mạng và gia đình còn gặp khó khăn trong cuộc sống.