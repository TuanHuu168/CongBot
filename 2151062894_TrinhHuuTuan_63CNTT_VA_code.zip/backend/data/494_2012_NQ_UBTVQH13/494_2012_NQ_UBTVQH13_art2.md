# 494_2012_NQ_UBTVQH13_art2

Điều 2.

Ủy ban thường vụ Quốc hội yêu cầu Chính phủ, Thủ tướng Chính phủ tập trung thực hiện một số nhiệm vụ và giải pháp sau đây:

1. Tiếp tục điều chỉnh nâng mức trợ cấp, phụ cấp đối với người có công với cách mạng đồng bộ với lộ trình điều chỉnh tiền lương của cán bộ, công chức nhà nước cùng với việc thực hiện các chính sách ưu đãi khác để bảo đảm mục tiêu người có công với cách mạng có mức sống bằng hoặc cao hơn mức sống trung bình của dân cư nơi cư trú.

2. Tiếp tục thực hiện chính sách hỗ trợ về nhà ở đối với hộ người có công với cách mạng đang ở nhà tạm hoặc nhà bị hư hỏng nặng từ nguồn ngân sách nhà nước và huy động sự tham gia của xã hội, gia đình; chỉ đạo việc xây dựng tiêu chí hỗ trợ và rà soát đối tượng cần hỗ trợ xây mới hoặc sửa chữa nhà ở, cân đối ngân sách để thực hiện cơ bản xong trong hai năm 2012 - 2013. Trước mắt, dành một phần tăng thu ngân sách nhà nước năm 2011 bổ sung dự phòng ngân sách năm 2012 để thực hiện chính sách này.

3. Phê duyệt Đề án tìm kiếm, quy tập hài cốt liệt sỹ và Đề án xác định danh tính hài cốt liệt sỹ còn thiếu thông tin trong năm 2012 để tiếp tục triển khai thực hiện.

4. Hướng dẫn giải quyết các vướng mắc, tồn đọng đối với hồ sơ đề nghị công nhận người có công với cách mạng; tiếp tục cải cách thủ tục hành chính bảo đảm việc xem xét, xác nhận, để người có công với cách mạng được thụ hưởng chính sách thuận lợi, kịp thời, chính xác, đúng quy định.

5. Chỉ đạo các bộ, ngành, Ủy ban nhân dân các cấp tiếp tục đẩy mạnh công tác tuyên truyền, tổ chức thực hiện nghiêm túc; tăng cường công tác thanh tra, kiểm tra và xử lý nghiêm các vi phạm pháp luật; vận động xã hội tham gia thực hiện chính sách, pháp luật về người có công với cách mạng.