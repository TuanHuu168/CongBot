# 494_2012_NQ_UBTVQH13_preamble


| ỦY BAN THƯỜNG VỤ | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------- |
|---|---|
| Số: 494/NQ-UBTVQH13 | Hà Nội, ngày 18 tháng 05 năm 2012 |

NGHỊ QUYẾT

VỀ KẾT QUẢ GIÁM SÁT VIỆC THỰC HIỆN CHÍNH SÁCH, PHÁP LUẬT VỀ NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

ỦY BAN THƯỜNG VỤ QUỐC HỘI

Căn cứ Hiến pháp nước Cộng hòa xã hội chủ nghĩa Việt Nam năm 1992 đã được sửa đổi, bổ sung một số điều theo Nghị quyết số 51/2001/QH10;

Căn cứ Luật hoạt động giám sát của Quốc hội;

Căn cứ Nghị quyết số 407/NQ-UBTVQH13 ngày 22 tháng 11 năm 2011 của Ủy ban thường vụ Quốc hội về Chương trình hoạt động giám sát của Ủy ban thường vụ Quốc hội năm 2012;

Trên cơ sở xem xét Báo cáo kết quả giám sát số 120/BC-ĐGS ngày 12 tháng 4 năm 2012 của Đoàn giám sát của Ủy ban thường vụ Quốc hội, Báo cáo số 31/BC-CP ngày 29 tháng 2 năm 2012 của Chính phủ về việc thực hiện chính sách, pháp luật ưu đãi về người có công với cách mạng,

QUYẾT NGHỊ: