# 4804_2024_VBHN_BLĐTBXH_appendix6

PHỤ LỤC VI

MỨC HƯỞNG TRỢ CẤP ƯU ĐÃI MỘT LẦN ĐỐI VỚI NGƯỜI BỊ THƯƠNG CÓ TỶ LỆ TỔN THƯƠNG CƠ THỂ TỪ 5%-20%

| Đối tượng | Mức trợ cấp |
|---|---|
| Người bị thương thuộc một trong các trường hợp quy định tại Điều 23 Pháp lệnh số 02/2020/UBTVQH14 ngày 09 tháng 12 năm 2020 của Ủy ban Thường vụ Quốc hội khóa XIV mà có tỷ lệ tổn thương cơ thể từ 5% - 20% thì được hưởng trợ cấp ưu đãi một lần như sau: |  |
| Tỷ lệ tổn thương cơ thể từ 5% - 10% | 4,0 lần mức chuẩn |
| Tỷ lệ tổn thương cơ thể từ 11% - 15% | 6,0 lần mức chuẩn |
| Tỷ lệ tổn thương cơ thể từ 16% - 20% | 8,0 lần mức chuẩn |