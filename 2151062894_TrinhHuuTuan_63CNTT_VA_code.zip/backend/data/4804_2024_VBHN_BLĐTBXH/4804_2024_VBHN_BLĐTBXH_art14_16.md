# 4804_2024_VBHN_BLĐTBXH_art14_16

Chương IV

TỔ CHỨC THỰC HIỆN VÀ ĐIỀU KHOẢN THI HÀNH[17]

Điều 14. Tổ chức thực hiện

1. Bộ Lao động - Thương binh và Xã hội chủ trì, phối hợp với Bộ Thông tin và Truyền thông và các bộ, cơ quan liên quan tổ chức tuyên truyền về công tác người có công với cách mạng.

2. Bộ Lao động - Thương binh và Xã hội chủ trì, phối hợp với Bộ Tài chính hướng dẫn việc tổ chức thực hiện chi trả trợ cấp, phụ cấp và các chế độ ưu đãi người có công với cách mạng đảm bảo đúng đối tượng, đầy đủ, kịp thời và phù hợp với quy định hiện hành.

3. Bộ Lao động - Thương binh và Xã hội ủy quyền cho Sở Lao động - Thương binh và Xã hội thực hiện nhiệm vụ chi của ngân sách trung ương tại địa phương.

4.[18] Bố trí kinh phí chi quản lý bằng 1,7% tổng kinh phí từ nguồn ngân sách trung ương thực hiện Pháp lệnh Ưu đãi người có công với cách mạng trong dự toán ngân sách hằng năm (trừ kinh phí hỗ trợ các cơ sở nuôi dưỡng, điều dưỡng và chi công tác mộ liệt sĩ, nghĩa trang liệt sĩ) của Bộ Lao động - Thương binh và Xã hội, Bộ Quốc phòng, Bộ Công an để tổ chức thực hiện Pháp lệnh, tăng cường kiểm tra, kiểm soát, đảm bảo quản lý chặt chẽ, minh bạch ngân sách nhà nước thực hiện chính sách ưu đãi người có công với cách mạng.

Điều 15. Hiệu lực thi hành

1. Nghị định này có hiệu lực từ ngày 15 tháng 9 năm 2021.

2. Chế độ quy định tại Điều 4, 5 và 12 Nghị định này được thực hiện kể từ ngày 01 tháng 7 năm 2021.

3. Chế độ quy định tại Điều 6, 7, 8, 9, 10, 11 và 13 Nghị định này được thực hiện kể từ ngày 01 tháng 01 năm 2022.

Các chế độ tương ứng quy định tại khoản này đang thực hiện theo Nghị định số 58/2019/NĐ-CP ngày 01 tháng 7 năm 2019 của Chính phủ quy định mức trợ cấp, phụ cấp ưu đãi người có công với cách mạng, Nghị định số 31/2013/NĐ-CP ngày 09 tháng 4 năm 2013 của Chính phủ quy định chi tiết, hướng dẫn thi hành một số điều của Pháp lệnh Ưu đãi người có công với cách mạng và các văn bản khác tiếp tục được thực hiện cho đến ngày 31 tháng 12 năm 2021.

4. Nghị định số 58/2019/NĐ-CP ngày 01 tháng 7 năm 2019 của Chính phủ quy định mức trợ cấp, phụ cấp ưu đãi người có công với cách mạng hết hiệu lực thi hành kể từ ngày Nghị định này có hiệu lực thi hành, trừ các chế độ quy định tại khoản 3 Điều này.

5. Người bị thương thuộc một trong các trường hợp quy định tại Điều 23 Pháp lệnh số 02/2020/UBTVQH14 ngày 09 tháng 12 năm 2020 của Ủy ban Thường vụ Quốc hội khóa XIV về Ưu đãi người có công với cách mạng mà có tỷ lệ tổn thương cơ thể từ 5% - 20% thì được hưởng trợ cấp ưu đãi một lần theo quy định tại Phụ lục VI ban hành kèm theo Nghị định này.

Điều 16. Trách nhiệm thi hành

Bộ trưởng Bộ Lao động - Thương binh và Xã hội, các Bộ trưởng, Thủ trưởng cơ quan ngang bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân các tỉnh, thành phố trực thuộc trung ương chịu trách nhiệm thi hành Nghị định này./.

| Nơi nhận: - Văn phòng Chính phủ (để đăng công báo); - Bộ trưởng (để báo cáo); - Cổng Thông tin điện tử Chính phủ; - Trang Thông tin điện tử của Bộ (để đăng tải); - Lưu: Văn thư, CNCC. | XÁC THỰC VĂN BẢN HỢP NHẤT KT. BỘ TRƯỞNG THỨ TRƯỞNG Nguyễn Bá Hoan |