# 101_2018_TT_BTC_ch2_art7
Điều 7. Chi cấp phương tiện trợ giúp, dụng cụ chỉnh hình

1. Nguyên tắc cấp phương tiện trợ giúp, dụng cụ chỉnh hình

a) Cấp tiền để đối tượng mua phương tiện trợ giúp, dụng cụ chỉnh hình theo niên hạn sử dụng theo quy định;

b) Mức tiền cấp mua phương tiện trợ giúp, dụng cụ chỉnh hình (bao gồm cả tiền mua vật phẩm phụ, bảo trì phương tiện) theo phụ lục ban hành kèm theo Thông tư này;

c) Việc cấp tiền mua phương tiện trợ giúp, dụng cụ chỉnh hình (bao gồm cả tiền mua vật phẩm phụ, bảo trì phương tiện) được thực hiện một lần vào đầu niên hạn sử dụng.

2. Chế độ hỗ trợ khi đi làm phương tiện trợ giúp, dụng cụ chỉnh hình, điều trị phục hồi chức năng

a) Đối tượng được hưởng chế độ cấp phương tiện trợ giúp, dụng cụ chỉnh hình khi đi làm dụng cụ chỉnh hình, phương tiện trợ giúp được hỗ trợ một lần tiền ăn và tiền tàu xe (bao gồm cả lượt đi và về), mỗi niên hạn 01 lần. Mức hỗ trợ theo đơn giá 5.000 đồng/km nhân với khoảng cách từ nơi cư trú đến cơ sở y tế gần nhất đủ điều kiện về chuyên môn kỹ thuật cung cấp dụng cụ chỉnh hình, nhưng tối đa không quá 1.400.000 đồng/người;

Ví dụ: Ông Nguyễn Văn A là thương binh khi đi làm chân giả được hỗ trợ một lần tiền ăn và tiền tàu xe. Khoảng cách từ nhà Ông Nguyễn Văn A đến Trung tâm Chỉnh hình Phục hồi chức năng gần nhất là 175 km. Ông Nguyễn Văn A được hỗ trợ một lần tiền ăn và tiền tàu xe cho cả lượt đi và về là: 5.000 đồng x 175 km = 875.000 đồng;

b) Đối tượng được hưởng chế độ phục hồi chức năng khi đi điều trị phục hồi chức năng theo chỉ định của bệnh viện cấp tỉnh trở lên được hỗ trợ một lần tiền ăn và tiền tàu xe (theo khoảng cách từ nơi cư trú đến cơ sở phục hồi chức năng gần nhất đủ điều kiện về chuyên môn kỹ thuật): Mức hỗ trợ thực hiện theo quy định tại điểm a khoản này.

3. Đối tượng, quy trình, thủ tục lập sổ theo dõi và cấp phương tiện trợ giúp, dụng cụ chỉnh hình thực hiện theo quy định của Bộ LĐTBXH.