# 101_2018_TT_BTC_ch2_art5
Điều 5. Chi đóng bảo hiểm y tế

1. Đóng bảo hiểm y tế đối với những người đang hưởng chế độ trợ cấp, phụ cấp hàng tháng quy định tại khoản 1 Điều 4 Thông tư này (trừ những người đồng thời đang tham gia bảo hiểm xã hội bắt buộc, hưởng lương hưu, trợ cấp bảo hiểm xã hội, trợ cấp bảo hiểm thất nghiệp hàng tháng); đối tượng không hưởng trợ cấp hàng tháng được cấp thẻ bảo hiểm y tế theo quy định của Pháp lệnh ưu đãi người có công với cách mạng và thanh niên xung phong thời kỳ kháng chiến chống Pháp theo Quyết định số 170/2008/QĐ-TTg .

2. Hằng quý, cơ quan LĐTBXH căn cứ danh sách đối tượng đóng bảo hiểm y tế đã được rà soát theo quy định tại khoản 1 Điều này, đối chiếu với cơ quan bảo hiểm xã hội làm thủ tục rút dự toán kinh phí tại KBNN để chuyển kinh phí vào quỹ bảo hiểm y tế.

3. Số tiền đóng, phương thức đóng bảo hiểm y tế hằng quý thực hiện theo quy định của pháp luật về bảo hiểm y tế.