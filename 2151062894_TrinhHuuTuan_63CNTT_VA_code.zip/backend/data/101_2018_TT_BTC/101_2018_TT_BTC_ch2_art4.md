# 101_2018_TT_BTC_ch2_art4
Chương II

CHI THỰC HIỆN CHẾ ĐỘ ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG VÀ NGƯỜI TRỰC TIẾP THAM GIA KHÁNG CHIẾN

Điều 4. Chi chế độ trợ cấp, phụ cấp

1. Chi chế độ trợ cấp hàng tháng, phụ cấp hàng tháng, trợ cấp một lần đối với các đối tượng theo quy định tại Điều 1 Pháp lệnh sửa đổi, bổ sung một số điều của Pháp lệnh ưu đãi người có công với cách mạng ngày 16 tháng 7 năm 2012.

2. Chi chế độ trợ cấp hàng tháng, trợ cấp một lần đối với người trực tiếp tham gia kháng chiến do ngành LĐTBXH quản lý, gồm:

a) Trợ cấp hàng tháng đối với:

- Cán bộ, chiến sĩ Công an nhân dân tham gia kháng chiến chống Mỹ có dưới 20 năm công tác trong Công an nhân dân đã thôi việc, xuất ngũ về địa phương theo Quyết định số 53/2010/QĐ-TTg ;

- Quân nhân tham gia kháng chiến chống Mỹ cứu nước có dưới 20 năm công tác trong quân đội, đã phục viên, xuất ngũ về địa phương theo Quyết định số 142/2008/QĐ-TTg và Quyết định số 38/2010/QĐ-TTg ;

b) Trợ cấp hàng tháng và trợ cấp một lần đối với người tham gia chiến tranh bảo vệ Tổ quốc, làm nhiệm vụ quốc tế ở Căm-pu-chi-a, giúp bạn Lào sau ngày 30 tháng 4 năm 1975 đã phục viên, xuất ngũ, thôi việc theo Quyết định số 62/2011/QĐ-TTg ;

c) Trợ cấp một lần đối với:

- Quân nhân, cán bộ đi chiến trường B, C, K trong thời kỳ chống Mỹ cứu nước không có thân nhân phải trực tiếp nuôi dưỡng và quân nhân, cán bộ được Đảng cử lại miền Nam sau Hiệp định Giơnevơ năm 1954 theo Nghị định số 23/1999/NĐ-CP ;

- Người trực tiếp tham gia kháng chiến chống Mỹ cứu nước nhưng chưa được hưởng chính sách của Đảng và Nhà nước theo Quyết định số 290/2005/QĐ-TTg và Quyết định số 188/2007/QĐ-TTg ;

- Thanh niên xung phong đã hoàn thành nhiệm vụ trong kháng chiến theo Quyết định số 40/2011/QĐ-TTg ; thanh niên xung phong cơ sở ở miền Nam tham gia kháng chiến theo Nghị định số 112/2017/NĐ-CP ;

- Người được cử làm chuyên gia sang giúp Lào và Căm-pu-chi-a theo Quyết định số 57/2013/QĐ-TTg và Quyết định số 62/2015/QĐ-TTg ;

d) Trợ cấp hàng tháng, trợ cấp một lần đối với các đối tượng chính sách khác theo quy định của pháp luật.