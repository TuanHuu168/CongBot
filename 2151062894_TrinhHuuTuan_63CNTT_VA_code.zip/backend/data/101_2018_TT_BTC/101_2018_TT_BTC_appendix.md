# 101_2018_TT_BTC_appendix
PHỤ LỤC

MỨC TIỀN CẤP MUA PHƯƠNG TIỆN TRỢ GIÚP, DỤNG CỤ CHỈNH HÌNH, VẬT PHẨM PHỤ VÀ VẬT DỤNG KHÁC (Ban hành kèm theo Thông tư số 101 /2018/TT-BTC ngày 14/11/2018 của Bộ Tài chính)

| Số TT | Tên sản phẩm/nhóm sản phẩm | Niên hạn cấp | Mức cấp (đồng) |
|---|---|---|---|
| 1 | Tay giả tháo khớp vai | 03 năm | 3.100.000 |
| 2 | Tay giả trên khuỷu | 03 năm | 3.380.000 |
| 3 | Tay giả dưới khuỷu | 03 năm | 2.220.000 |
| 4 | Chân tháo khớp hông | 03 năm | 5.880.000 |
| 5 | Chân giả trên gối | 02 năm | 3.800.000 |
| 6 | Nhóm chân giả tháo khớp gối | 03 năm | 4.340.000 |
| 7 | Chân giả dưới gối có bao da đùi | 02 năm | 3.600.000 |
| 8 | Chân giả dưới gối có dây đeo số 8 | 02 năm | 3.400.000 |
| 9 | Chân giả tháo khớp cổ chân | 03 năm | 2.260.000 |
| 10 | Nhóm nẹp Ụ ngồi-Đai hông | 03 năm | 4.870.000 |
| 11 | Nẹp đùi | 03 năm | 2.750.000 |
| 12 | Nẹp cẳng chân | 03 năm | 1.630.000 |
| 13 | Nhóm máng nhựa chân và tay | 05 năm | 3.350000 |
| 14 | Giầy chỉnh hình | 01 năm | 1.450.000 |
| 15 | Dép chỉnh hình | 01 năm | 850.000 |
| 16 | Áo chỉnh hình | 05 năm | 3.120.000 |
| 17 | Xe lắc tay | 04 năm | 4.550.000 |
| 18 | Xe lăn tay | 04 năm | 2.500.000 |
| 19 | Nạng cho người bị cứng khớp gối | 01 năm | 200.000 |
| 20 | Máy trợ thính | 01 năm | 450.000 |
| 21 | Răng giả | 05 năm | 1.110.000 |
| 22 | Hàm giả | 05 năm | 4.450.000 |
| 23 | Vật phẩm phụ: |  |  |
|  | - Người được cấp chân giả | 01 năm | 200.000 |
|  | - Người được cấp tay giả | 01 năm | 100.000 |
|  | - Người được cấp nạng | 01 năm | 100.000 |
|  | - Người được lắp mắt giả | 01 năm | 200.000 |
|  | - Người được cấp áo chỉnh hình | 01 năm | 200.000 |
| 24 | Bảo trì phương tiện đối với trường hợp được cấp tiền mua xe lăn, xe lắc | 01 năm | 350.000 |
| 25 | Kính râm và gậy dò đường | 01 năm | 150.000 |
| 26 | Đồ dùng phục vụ sinh hoạt | 01 năm | 1.150.000 |