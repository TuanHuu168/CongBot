# 47_2009_TTLT_BTC_BLĐTBXH_art1_2
MỤC I. NHỮNG QUY ĐỊNH CHUNG

Điều 1. Nguồn kinh phí thực hiện

1. Kinh phí thực hiện chính sách ưu đãi người có công với cách mạng theo hướng dẫn tại Thông tư này bao gồm các khoản chi trợ cấp thường xuyên (gồm cả chi trợ cấp một lần theo chế độ thường xuyên, các khoản chi ưu đãi khác, chi hỗ trợ hoạt động các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng và chi phí quản lý) và khoản chi trợ cấp một lần.

2. Ngân sách Trung ương đảm bảo nguồn kinh phí để thực hiện chính sách ưu đãi người có công với cách mạng; Bộ Tài chính, Kho bạc Nhà nước bảo đảm đầy đủ, kịp thời kinh phí cho cơ quan Lao động – Thương binh và Xã hội để thực hiện chính sách.

3. Cơ quan Lao động – Thương binh và Xã hội chủ trì, phối hợp với Kho bạc Nhà nước quản lý nguồn kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và tổ chức thực hiện chi, trả kịp thời, đúng chế độ, đúng nội dung, đúng đối tượng theo quy định tại Thông tư này.

Điều 2. Quy định chung về quản lý kinh phí

1. Sở Lao động – Thương binh và Xã hội, phòng Lao động – Thương binh và Xã hội và các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng mở tài khoản dự toán tại Kho bạc Nhà nước và thực hiện rút dự toán theo quy định.

2. Số dư dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng đến hết niên độ ngân sách năm dự toán (bao gồm cả thời gian chỉnh lý quyết toán theo chế độ quy định) không sử dụng hết thì bị hủy bỏ.

3. Đối với các khoản lĩnh trùng, cấp trùng, chi sai chế độ: Ngành Lao động – Thương binh và Xã hội phối hợp với Kho bạc Nhà nước nơi đơn vị giao dịch thực hiện thu hồi, nộp ngân sách nhà nước theo quy định.

4. Kinh phí thực hiện chính sách ưu đãi người có công với cách mạng được sử dụng, quản lý và quyết toán theo quy định của Luật Ngân sách nhà nước, Luật Kế toán, các văn bản hướng dẫn Luật và quy định cụ thể tại Thông tư này.

5. Chi mua sắm, sửa chữa tài sản thực hiện theo quy định hiện hành của Bộ Tài chính về mua sắm, sửa chữa tài sản.