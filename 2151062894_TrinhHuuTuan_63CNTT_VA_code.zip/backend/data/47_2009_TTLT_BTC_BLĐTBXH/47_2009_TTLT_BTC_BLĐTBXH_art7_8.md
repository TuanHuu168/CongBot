# 47_2009_TTLT_BTC_BLĐTBXH_art7_8
MỤC III. QUẢN LÝ KINH PHÍ

Điều 7. Lập dự toán kinh phí

1. Dự toán kinh phí thực hiện các chính sách ưu đãi người có công với cách mạng phải chi tiết theo từng loại trợ cấp hàng tháng, trợ cấp một lần và thể hiện đầy đủ nội dung chi nêu tại mục II Thông tư này.

2. Lập dự toán kinh phí hàng năm được thực hiện theo quy định của Luật Ngân sách nhà nước và các văn bản hướng dẫn Luật. Ngoài ra, Thông tư này hướng dẫn cụ thể quy trình và trình tự thời gian lập dự toán như sau:

a) Phòng Lao động – Thương binh và Xã hội quận, huyện, thị xã, thành phố thuộc tỉnh và cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng trực thuộc Sở Lao động – Thương binh và Xã hội, lập dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng của năm kế hoạch gửi Sở Lao động – Thương binh và Xã hội trước ngày 20 tháng 6 hàng năm.

b) Sở Lao động – Thương binh và Xã hội xem xét dự toán của các Phòng Lao động – Thương binh và Xã hội, cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng và dự toán chi tại Sở, tổng hợp dự toán kinh phí chi ưu đãi người có công cách mạng của tỉnh, thành phố trực thuộc Trung ương gửi Bộ Lao động – Thương binh và Xã hội trước ngày 5 tháng 7 hàng năm.

c) Bộ Lao động – Thương binh và Xã hội xem xét dự toán kinh phí trợ cấp người có công với cách mạng của các Sở Lao động – Thương binh và Xã hội; tổng hợp dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng gửi Bộ Tài chính trước ngày 20 tháng 7 hàng năm.

d) Bộ Tài chính xem xét và tổng hợp dự toán kinh phí chi ưu đãi người có công với cách mạng vào dự toán chi ngân sách nhà nước, báo cáo Chính phủ trình Quốc hội phê duyệt và giao dự toán cho Bộ Lao động – Thương binh và Xã hội trước ngày 20/11 hàng năm.

Điều 8. Phân bổ và giao dự toán

1. Căn cứ vào dự toán ngân sách được Thủ tướng Chính phủ giao, Bộ Tài chính giao dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng cho Bộ Lao động – Thương binh và Xã hội.

2. Căn cứ dự toán ngân sách được giao, Bộ Lao động – Thương binh và Xã hội dự kiến phương án phân bổ dự toán cho các Sở Lao động – Thương binh và Xã hội các tỉnh, thành phố trực thuộc Trung ương theo loại 520, khoản 527 của Mục lục ngân sách nhà nước gửi Bộ Tài chính trước ngày 30/11 hàng năm để thẩm tra. Trong vòng 7 ngày làm việc, kể từ khi nhận được phương án phân bổ của Bộ Lao động – Thương binh và Xã hội, Bộ Tài chính thông báo bằng văn bản kết quả thẩm tra phân bổ dự toán cho Bộ Lao động – Thương binh và Xã hội.

3. Căn cứ phương án phân bổ ngân sách được Bộ Tài chính thống nhất, Bộ Lao động – Thương binh và Xã hội thực hiện giao dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng theo loại, khoản của Mục lục ngân sách nhà nước cho các Sở Lao động – Thương binh và Xã hội tỉnh, thành phố trực thuộc Trung ương trước ngày 15/12 hàng năm, đồng thời ủy quyền cho các Sở Lao động – Thương binh và Xã hội phân bổ, giao dự toán cho các đơn vị sử dụng ngân sách (Phòng Lao động – Thương binh và Xã hội, cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng và kinh phí chi tại Sở Lao động – Thương binh và Xã hội) trước ngày 31/12 hàng năm.

Riêng đối với dự toán kinh phí trợ cấp ưu đãi một lần người có công với cách mạng, Bộ Lao động – Thương binh và Xã hội được giữ lại tại đơn vị dự toán cấp I và thực hiện phân bổ, giao bổ sung dự toán cho các Sở Lao động – Thương binh và Xã hội khi có Quyết định phê duyệt đối tượng hưởng trợ cấp của Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương (hoặc cơ quan được ủy quyền) để thực hiện chi trả cho các đối tượng theo quy định.

4. Bộ Lao động – Thương binh và Xã hội tổng hợp và chịu trách nhiệm về toàn bộ dự toán kinh phí trợ cấp người có công với cách mạng đã phân bổ và giao cho các đơn vị sử dụng ngân sách. Quyết định giao dự toán cho các đơn vị được gửi đến Kho bạc Nhà nước nơi đơn vị sử dụng ngân sách mở tài khoản giao dịch để phối hợp thực hiện.