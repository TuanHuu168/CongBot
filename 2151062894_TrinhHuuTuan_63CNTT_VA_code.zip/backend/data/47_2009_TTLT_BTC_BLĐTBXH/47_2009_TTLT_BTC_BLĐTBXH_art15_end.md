# 47_2009_TTLT_BTC_BLĐTBXH_art15_end
MỤC IV. TỔ CHỨC THỰC HIỆN

Điều 15. Hiệu lực thi hành

1. Thông tư này áp dụng từ năm ngân sách 2009, có hiệu lực thi hành sau 45 ngày kể từ ngày ký và thay thế Thông tư liên tịch số 84/2005/TTLT/BTC-BLĐTBXH ngày 23/9/2005 của Liên Bộ Tài chính – Bộ Lao động – Thương binh và Xã hội hướng dẫn cấp phát, quản lý kinh phí thực hiện chính sách đối với người có công với cách mạng do ngành Lao động – Thương binh và Xã hội quản lý.

2. Sở Lao động – Thương binh và Xã hội, Kho bạc Nhà nước các tỉnh, thành phố trực thuộc Trung ương có trách nhiệm phối hợp, hướng dẫn và tổ chức thực hiện Thông tư này./.

| KT. BỘ TRƯỞNG BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI THỨ TRƯỞNG Bùi Hồng Lĩnh | KT. BỘ TRƯỞNG BỘ TÀI CHÍNH THỨ TRƯỞNG Phạm Sỹ Danh |
|---|---|
| Nơi nhận: - Ban Bí thư TW Đảng, Thủ tướng Chính phủ, các Phó TTCP; - Văn phòng Trung ương và các Ban của Đảng; - Văn phòng Quốc hội; - Văn phòng Chủ tịch nước; - Văn phòng Chính phủ; - Tòa án nhân dân tối cao; - Viện kiểm sát nhân dân tối cao; - Cơ quan Trung ương của các đoàn thể; - Kiểm toán Nhà nước; - Các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ; - UBND các tỉnh, thành phố trực thuộc Trung ương; - Sở Tài chính, Kho bạc Nhà nước, Sở LĐTBXH các tỉnh, thành phố trực thuộc Trung ương; - Cục Kiểm tra văn bản QPPL – Bộ Tư pháp; - Công báo; - Website Chính phủ; Website Bộ Tài chính, Bộ LĐTBXH; - Các đơn vị thuộc Bộ Tài chính, Bộ LĐTBXH; - Lưu VT: Bộ Tài chính, Bộ LĐTBXH |  |