# 47_2009_TTLT_BTC_BLĐTBXH_art4
Điều 4. Các khoản chi ưu đãi khác

1. Chi cấp Báo Nhân dân cho người hoạt động cách mạng trước ngày 01/01/1945, người hoạt động cách mạng từ ngày 01/01/1945 đến trước tổng khởi nghĩa 19/8/1945.

2. Bảo hiểm y tế.

3. Trợ cấp lễ báo tử liệt sỹ.

4. Trợ cấp mai táng phí.

5. Điều trị, điều dưỡng phục hồi sức khỏe, chức năng lao động.

6. Quà tặng của Chủ tịch nước, chi ăn thêm ngày lễ, tết.

7. Thuốc đặc trị và các điều trị đặc biệt khác cho thương binh, bệnh binh, người hưởng chính sách như thương binh điều trị vết thương, bệnh tật tái phát.

8. Giám định y khoa cho thương binh, bệnh binh, người nhiễm chất độc hóa học, người hưởng chính sách như thương binh, bệnh binh.

9. Phương tiện trợ giúp, dụng cụ chỉnh hình cần thiết đối với đối tượng quy định tại Thông tư liên tịch số 17/2006/TTLT-BLĐTBXH-BTC-BYT ngày 21/11/2006 của liên Bộ Lao động – Thương binh và Xã hội – Bộ Tài chính – Bộ Y tế hướng dẫn chế độ chăm sóc sức khỏe đối với người có công với cách mạng và các văn bản sửa đổi, bổ sung (nếu có).

10. Hỗ trợ tiền tàu, xe, đi khám chữa bệnh, giám định thương tật.

11. Hỗ trợ tiền tàu, xe, lưu trú làm dụng cụ chỉnh hình, phục hồi chức năng theo quy định tại Thông tư liên tịch số 17/2006/TTLT-BLĐTBXH-BTC-BYT ngày 21/11/2006 của liên Bộ Lao động – Thương binh và Xã hội – Bộ Tài chính – Bộ Y tế hướng dẫn chế độ chăm sóc sức khỏe đối với người có công với cách mạng và các văn bản sửa đổi, bổ sung.

12. Chi hỗ trợ thương binh, bệnh binh nặng đang được nuôi dưỡng tập trung tại các cơ sở nuôi dưỡng người có công với cách mạng về sống với gia đình. Mức chi do Bộ trưởng Bộ Lao động – Thương binh và Xã hội quyết định sau khi có ý kiến thỏa thuận bằng văn bản của Bộ Tài Chính.

13. Chi công tác mộ liệt sỹ: Khảo sát, tìm kiếm, quy tập mộ, đón nhận, an táng; hỗ trợ sửa chữa nâng cấp, xây mới mộ liệt sỹ, nghĩa trang liệt sỹ và các công trình ghi công liệt sỹ.

14. Hỗ trợ thân nhân liệt sỹ thăm viếng mộ và di chuyển hài cốt liệt sỹ.

15. Đón tiếp người có công với cách mạng.

16. Trợ cấp ưu đãi trong giáo dục, đào tạo.

17. Các khoản chi ưu đãi khác theo quy định của pháp luật.