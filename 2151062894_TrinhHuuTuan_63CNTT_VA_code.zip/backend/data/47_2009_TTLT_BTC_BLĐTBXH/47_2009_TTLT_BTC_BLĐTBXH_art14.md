# 47_2009_TTLT_BTC_BLĐTBXH_art14
Điều 14. Kiểm soát chi của Kho bạc Nhà nước

1. Kho bạc Nhà nước thực hiện kiểm soát kinh phí thực hiện chính sách ưu đãi người có công với cách mạng theo quy định hiện hành.

2. Hồ sơ làm căn cứ để Kho bạc Nhà nước kiểm soát chi

a) Đối với các khoản chi trợ cấp ưu đãi hàng tháng:

- Danh sách chi trả trợ cấp ưu đãi hàng tháng (lập theo mẫu số C67-HD/LĐTBXH quy định tại Quyết định số 09/2007/QĐ-BLĐTBXH ngày 31/3/2007 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội về việc Ban hành bổ sung mẫu các loại chứng từ, tài khoản kế toán, sổ kế toán, báo cáo tài chính vào Chế độ kế toán Hành chính sự nghiệp theo Quyết định số 19 TC/QĐ/CĐKT ngày 30/3/2006 của Bộ trưởng Bộ Tài chính áp dụng cho kế toán nguồn ngân sách Trung ương thực hiện chính sách đối với người có công với cách mạng do ngành Lao động – Thương binh và Xã hội quản lý) do cơ quan Lao động – Thương binh và Xã hội (Sở, Phòng Lao động – Thương binh và Xã hội; cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng) lập và gửi Kho bạc Nhà nước nơi giao dịch. Thủ trưởng cơ quan Lao động – Thương binh và Xã hội có trách nhiệm ký, đóng dấu và gửi một lần ban đầu cho Kho bạc Nhà nước nơi đơn vị mở tài khoản giao dịch trước ngày 20/12 của năm trước. Ngoài ra, nếu trong năm có sự biến động tăng, giảm đối tượng, thủ trưởng cơ quan Lao động – Thương binh và Xã hội gửi Bảng tổng hợp bổ sung danh sách đối tượng tăng, giảm (lập theo mẫu số C62-HD/LĐTBXH và mẫu số C64-HD/LĐTBXH quy định tại Quyết định 09/2007/QĐ-BLĐTBXH ngày 31/3/2007 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội).

- Bảng kê điều chỉnh trợ cấp ưu đãi hàng tháng theo mẫu số C63 – HD/LĐTBXH (nếu có) quy định tại Quyết định số 09/2007/QĐ-BLĐTBXH ngày 31/3/2007 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội.

- Danh sách chi trả trợ cấp ưu đãi giáo dục theo mẫu số C69-HD/LĐTBXH (nếu có) quy định tại Quyết định số 09/2007/QĐ-BLĐTBXH ngày 31/3/2007 của Bộ trưởng Bộ Lao động – Thương binh và Xã hội.

b) Đối với các khoản chi trợ cấp ưu đãi một lần:

- Danh sách chi trả trợ cấp một lần (bao gồm cả đối tượng được hưởng trợ cấp một lần theo quy định tại Nghị định số 54/2006/NĐ-CP ngày 26/5/2006) do Sở Lao động – Thương binh và Xã hội (Phòng Lao động – Thương binh và Xã hội) lập theo mẫu số C65-HD/LĐTBXH quy định tại Quyết định số 09/2007/QĐ-BLĐTBXH ngày 31/3/2007 gửi Bộ Lao động – Thương binh và Xã hội và Quyết định đối tượng hưởng trợ cấp do cơ quan có thẩm quyền quyết định (bản chính);

- Đối với các đối tượng được hưởng trợ cấp một lần theo quy định tại Quyết định số 290/2005/QĐ-TTg ngày 08/11/2005 và Quyết định số 188/2007/QĐ-TTg ngày 6/12/2007, đơn vị lập Bảng danh sách đối tượng theo mẫu số 9A, 9B Thông tư số 191/2005/TTLT-BQP-BLĐTBXH-BTC ngày 07/12/2005.

- Đối với các đối tượng được hưởng trợ cấp một lần theo quy định tại Nghị định số 23/1999/NĐ-CP ngày 15/4/1999, đơn vị lập Bảng danh sách đối tượng theo mẫu số 3A, 3B Thông tư liên tịch số 17/1999/TTLT-BLĐTBXH-BTC-BTCCBCP ngày 21/7/1999 của Bộ Lao động - Thương binh và Xã hội - Bộ Tài chính - Ban Tổ chức Cán bộ Chính phủ hướng dẫn thi hành Nghị định số 23/1999/NĐ-CP .

c) Đối với các khoản chi cho công tác mộ và nghĩa trang liệt sỹ:

- Chi cho công tác khảo sát, tìm kiếm, quy tập, cất bốc, xây và sửa vỏ mộ: Căn cứ dự toán được cấp có thẩm quyền giao và chế độ chi tiêu hiện hành; đối với nội dung chi chưa có quy định mức chi của nhà nước thì căn cứ chứng từ chi tiêu thực tế; thủ trưởng đơn vị chịu trách nhiệm về tính pháp lý của chứng từ.

- Chi hỗ trợ các công trình, dự án đầu tư hoặc có tính chất đầu tư: Quyết định phê duyệt dự án đầu tư của cấp có thẩm quyền; Quyết định phân bổ (hỗ trợ), dự toán chi cho công tác mộ, nghĩa trang liệt sỹ cho công trình của Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương (hoặc cơ quan được ủy quyền).

d) Đối với các khoản chi hỗ trợ hoạt động các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng và chi phí quản lý: Tùy theo tính chất, nội dung của từng khoản chi và quy định tại Thông tư này; Kho bạc Nhà nước thực hiện kiểm soát chi theo quy định tại các văn bản hiện hành áp dụng đối với từng lĩnh vực chi cụ thể.