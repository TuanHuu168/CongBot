# 47_2009_TTLT_BTC_BLĐTBXH_art9_11
Điều 9. Rút dự toán ngân sách

Căn cứ vào dự toán năm đã được cấp có thẩm quyền giao, đơn vị sử dụng ngân sách nhà nước (Sở Lao động – Thương binh và Xã hội, Phòng Lao động – Thương binh và Xã hội, cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng) thực hiện rút dự toán tại Kho bạc Nhà nước nơi đơn vị mở tài khoản để thực hiện chính sách ưu đãi người có công với cách mạng theo quy định tại mục II Thông tư này.

Điều 10. Tạm cấp ngân sách

1. Trường hợp vào đầu năm ngân sách, dự toán và phương án phân bổ kinh phí trợ cấp người có công với cách mạng chưa được cấp có thẩm quyền quyết định, Kho bạc Nhà nước nơi đơn vị mở tài khoản giao dịch tạm cấp kinh phí cho đơn vị để thực hiện chính sách ưu đãi người có công với cách mạng đảm bảo đúng thời hạn hàng tháng. Mức tạm cấp tối đa không quá mức kinh phí bình quân 01 tháng của năm trước.

2. Sau khi dự toán và phương án phân bổ ngân sách chi trợ cấp ưu đãi người có công với cách mạng được cơ quan nhà nước có thẩm quyền quyết định, Kho bạc Nhà nước thực hiện thu hồi số kinh phí tạm cấp bằng cách trừ vào các mục chi tương ứng trong dự toán ngân sách nhà nước phân bổ cho đơn vị.

3. Việc tạm cấp ngân sách chỉ áp dụng đối với kinh phí trợ cấp ưu đãi hàng tháng và kinh phí hỗ trợ hoạt động các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng; không áp dụng đối với trợ cấp ưu đãi một lần.

Điều 11. Điều chỉnh dự toán

1. Điều chỉnh dự toán trong nội bộ tỉnh

Trên cơ sở đề nghị của đơn vị, xác nhận của Kho bạc Nhà nước về số dư dự toán được giao còn lại và khả năng sử dụng kinh phí của các đơn vị trực thuộc khác; Sở Lao động – Thương binh và Xã hội ra quyết định điều chỉnh dự toán giữa các đơn vị sử dụng ngân sách trực thuộc (Phòng Lao động – Thương binh và Xã hội và cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng) và phần kinh phí trợ cấp ưu đãi người có công với cách mạng chi tại Sở. Quyết định điều chỉnh dự toán được gửi cho Bộ Lao động – Thương binh và Xã hội (để báo cáo) và Kho bạc Nhà nước nơi mở tài khoản giao dịch của các đơn vị liên quan đến điều chỉnh dự toán.

2. Điều chỉnh dự toán giữa các tỉnh

a) Trên cơ sở đề nghị của Sở Lao động – Thương binh và Xã hội tỉnh (kèm theo Bảng tổng hợp xác nhận của Kho bạc Nhà nước nơi đơn vị mở tài khoản giao dịch về số dư dự toán còn lại), Bộ Lao động – Thương binh và Xã hội ra quyết định điều chỉnh dự toán giữa các Sở Lao động – Thương binh và Xã hội nhưng đảm bảo nguyên tắc không vượt quá tổng số dự toán kinh phí thực hiện chính sách ưu đãi người có công với cách mạng được giao, đồng thời gửi Kho bạc Nhà nước tỉnh, thành phố trực thuộc Trung ương để kiểm soát chi và gửi Bộ Tài chính để báo cáo.

b) Căn cứ vào thông báo điều chỉnh dự toán của Bộ Lao động – Thương binh và Xã hội, Sở Lao động – Thương binh và Xã hội ra quyết định điều chỉnh dự toán cho các đơn vị sử dụng ngân sách trực thuộc và gửi Kho bạc Nhà nước nơi đơn vị mở tài khoản giao dịch để phối hợp thực hiện.