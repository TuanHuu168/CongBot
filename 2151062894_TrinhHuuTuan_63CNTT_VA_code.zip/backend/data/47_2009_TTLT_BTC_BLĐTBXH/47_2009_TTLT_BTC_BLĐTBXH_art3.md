# 47_2009_TTLT_BTC_BLĐTBXH_art3
MỤC II. NỘI DUNG VÀ MỨC CHI THỰC HIỆN CHÍNH SÁCH ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

Điều 3. Chi trợ cấp ưu đãi hàng tháng và trợ cấp một lần theo quy định hiện hành cho các đối tượng sau:

1. Các đối tượng quy định tại Điều 2, Pháp lệnh ưu đãi người có công với cách mạng số 26/2005/PL-UBTVQH11 ngày 29/6/2005 của Ủy ban thường vụ Quốc hội và Điều 1, Pháp lệnh số 35/2007/PL-UBTVQH11 ngày 21/6/2007 sửa đổi, bổ sung một số điều của Pháp lệnh ưu đãi người có công với cách mạng.

2. Thanh niên xung phong theo Quyết định số 104/1999/QĐ-TTg ngày 14/5/1999 của Thủ tướng Chính phủ về một số chính sách đối với thanh niên xung phong đã hoàn nhiệm vụ trong kháng chiến.

3. Quân nhân, cán bộ theo Nghị định số 23/1999/NĐ-CP ngày 15/4/1999 của Chính phủ về chế độ đối với quân nhân, cán bộ đi chiến trường B, C, K trong thời kỳ chống Mỹ cứu nước không có thân nhân phải trực tiếp nuôi dưỡng và quân nhân, cán bộ được Đảng cử lại miền Nam sau hiệp định Giơnevơ năm 1954.

4. Đối tượng trực tiếp tham gia kháng chiến chống Mỹ cứu nước nhưng chưa được hưởng chính sách của Đảng và Nhà nước theo Quyết định số 290/2005/QĐ-TTg ngày 8/11/2005 và Quyết định số 188/2007/QĐ-TTg ngày 6/12/2007 của Thủ tướng Chính phủ về việc sửa đổi, bổ sung Quyết định số 290/2005/QĐ-TTg .

5. Quân nhân phục viên, xuất ngũ theo Quyết định số 142/2008/QĐ-TTg ngày 27/10/2008 của Thủ tướng Chính phủ về thực hiện chế độ quân nhân tham gia kháng chiến chống Mỹ cứu nước có dưới 20 năm công tác trong quân đội đã phục viên, xuất ngũ về địa phương.

6. Thanh niên xung phong thời kỳ kháng chiến chống Pháp theo Quyết định số 170/2008/QĐ-TTg ngày 18/12/2008 của Thủ tướng Chính phủ về chế độ bảo hiểm y tế và trợ cấp mai táng đối với thanh niên xung phong thời kỳ kháng chiến chống Pháp.

7. Các đối tượng chính sách khác theo quy định của pháp luật.