# 47_2009_TTLT_BTC_BLĐTBXH_preamble
# Thông tư liên tịch số 47/2009/TTLT-BTC-BLĐTBXH của Bộ Tài chính, Bộ Lao động, Thương binh và Xã hội: Hướng dẫn cấp phát, quản lý và sử dụng kinh phí thực hiện chính sách ưu đãi người có công với cách mạng và người trực tiếp tham gia kháng chiến do ngành Lao động - Thương binh và Xã hội quản lý

| BỘ TÀI CHÍNH - BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập – Tự do – Hạnh phúc ------------ |
|---|---|
| Số: 47/2009/TTLT-BTC-BLĐTBXH | Hà Nội, ngày 11 tháng 03 năm 2009 |

THÔNG TƯ LIÊN TỊCH

HƯỚNG DẪN CẤP PHÁT, QUẢN LÝ VÀ SỬ DỤNG KINH PHÍ THỰC HIỆN CHÍNH SÁCH ƯU ĐÃI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG VÀ NGƯỜI TRỰC TIẾP THAM GIA KHÁNG CHIẾN DO NGÀNH LAO ĐỘNG – THƯƠNG BINH VÀ XÃ HỘI QUẢN LÝ

Căn cứ Nghị định số 60/2003/NĐ-CP ngày 06/6/2003 của Chính phủ quy định chi tiết và hướng dẫn thi hành Luật Ngân sách nhà nước. Căn cứ Nghị định số 54/2006/NĐ-CP ngày 26/5/2006 của Chính phủ hướng dẫn thi hành một số điều của Pháp lệnh ưu đãi người có công với cách mạng; Nghị định số 89/2008/NĐ-CP ngày 13/8/2008 của Chính phủ hướng dẫn thi hành Pháp lệnh sửa đổi, bổ sung một số điều của Pháp lệnh ưu đãi người có công với cách mạng và các văn bản quy phạm pháp luật bổ sung, sửa đổi liên quan khác của cấp có thẩm quyền về chính sách ưu đãi người có công với cách mạng. Bộ Tài chính – Bộ Lao động – Thương binh và Xã hội hướng dẫn cấp phát, quản lý và sử dụng kinh phí thực hiện chính sách ưu đãi người có công với cách mạng; người trực tiếp tham gia kháng chiến do ngành Lao động – Thương binh và Xã hội quản lý (sau đây gọi tắt là chính sách ưu đãi người có công với cách mạng) như sau: