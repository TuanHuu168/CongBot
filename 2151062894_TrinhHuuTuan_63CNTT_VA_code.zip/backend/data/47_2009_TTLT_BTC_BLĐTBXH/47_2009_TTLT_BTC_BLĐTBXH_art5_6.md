# 47_2009_TTLT_BTC_BLĐTBXH_art5_6
Điều 5. Chi hỗ trợ hoạt động các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng do ngành Lao động – Thương binh và Xã hội quản lý

Ngoài các khoản chi trợ cấp và chi ưu đãi nêu tại Điều 3 và Điều 4 trên, các cơ sở nuôi dưỡng, điều dưỡng người có công với cách mạng được hỗ trợ để chi các khoản sau:

1. Sửa chữa, nâng cấp nhà cửa, cơ sở hạ tầng.

2. Mua sắm, sửa chữa đồ dùng, trang thiết bị, phương tiện làm việc.

3. Chi thuê mướn nhân công, thanh toán dịch vụ công cộng, vật tư văn phòng, thông tin, liên lạc, tuyên truyền.

4. Chi sách báo, sinh hoạt văn hóa, thể thao.

5. Chi tàu, xe cho thương binh, bệnh binh về thăm gia đình; chi phí đón tiếp thân nhân người có công với cách mạng đến thăm người có công với cách mạng tại cơ sở nuôi dưỡng, điều dưỡng.

Nội dung và mức chi của các nội dung nêu tại Điều 4 và Điều 5 thực hiện theo các quy định hiện hành của Nhà nước. Đối với những nội dung chưa quy định mức chi, Giám đốc Sở Lao động – Thương binh và Xã hội quy định mức chi cụ thể trong phạm vi dự toán được giao.

Điều 6. Chi cho công tác quản lý

1. Để đảm bảo các hoạt động nghiệp vụ về quản lý đối tượng, quản lý hồ sơ và quản lý tài chính, kế toán đối với kinh phí thực hiện các chính sách ưu đãi người có công với cách mạng; hàng năm, ngành Lao động – Thương binh và Xã hội được trích 1,7%/tổng kinh phí thực hiện chính sách ưu đãi người có công với cách mạng để chi cho các nội dung sau:

a) Chi trả thù lao cho cán bộ trực tiếp chi trả trợ cấp. Mức chi cụ thể do Giám đốc Sở Lao động – Thương binh và Xã hội quy định phù hợp với điều kiện thực tế tại địa phương và hướng dẫn của Bộ Lao động – Thương binh và Xã hội.

b) Chi phổ biến chính sách ưu đãi người có công với cách mạng. Mức chi theo quy định hiện hành về phổ biến, giáo dục pháp luật.

c) Chi thông tin, tuyên truyền chính sách ưu đãi người có công với cách mạng trên các phương tiện thông tin đại chúng.

d) Chi văn phòng phẩm, in ấn biểu mẫu, mua sách, tài liệu phục vụ cho công tác quản lý. Mức chi thanh toán theo thực tế trên cơ sở dự toán được cấp có thẩm quyền phê duyệt.

đ) Chi tập huấn, bồi dưỡng nghiệp vụ, sơ kết, tổng kết. Nội dung và mức chi theo quy định hiện hành đào tạo, bồi dưỡng cán bộ, công chức và chế độ chi tổ chức các cuộc hội nghị tập huấn đối với các cơ quan nhà nước và đơn vị sự nghiệp công lập.

e) Chi xét duyệt, thẩm định điều chỉnh hồ sơ. Mức chi áp dụng theo quy định tại Thông tư liên tịch số 44/2007/TTLT-BTC-BKHCN ngày 7/5/2007 của Bộ Tài chính – Bộ Khoa học và Công nghệ hướng dẫn mức xây dựng và phân bổ dự toán kinh phí đối với các đề tài dự án khoa học có sử dụng ngân sách nhà nước và các văn bản sửa đổi, bổ sung (nếu có).

g) Chi mua sắm, sửa chữa tài sản, trang thiết bị, phương tiện phục vụ công tác chi trả và quản lý đối tượng. Mức chi căn cứ vào nhu cầu và dự toán được cấp có thẩm quyền phê duyệt.

h) Chi hỗ trợ ứng dụng công nghệ thông tin phục vụ công tác quản lý hồ sơ, quản lý đối tượng, quản lý chi trả trợ cấp cho đối tượng. Nội dung và mức chi theo quy định hiện hành về quản lý và sử dụng kinh phí ứng dụng công nghệ thông tin trong hoạt động của cơ quan nhà nước.

i) Chi phụ cấp làm đêm, thêm giờ. Mức chi theo quy định hiện hành về chế độ trả lương làm việc vào ban đêm, làm thêm giờ đối với cán bộ, công chức, viên chức.

k) Chi xăng dầu, thông tin liên lạc, trao đổi kinh nghiệm, thuê mướn và chi khác phục vụ công tác thực hiện chính sách ưu đãi người có công với cách mạng.

2. Bộ Lao động – Thương binh và Xã hội có trách nhiệm phân bổ phí quản lý phù hợp với đặc thù của từng địa phương và hướng dẫn các Sở Lao động – Thương binh và Xã hội quản lý, sử dụng, bảo đảm trong phạm vi tổng kinh phí chi cho công tác quản lý của toàn ngành. Riêng chi công tác quản lý tại Trung ương (bao gồm: Chi tập huấn nghiệp vụ, hỗ trợ ứng dụng công nghệ thông tin và chi khác phục vụ công tác quản lý) được phân bổ, sử dụng và quyết toán trong chi thường xuyên hàng năm của Bộ Lao động – Thương binh và Xã hội.

3. Đối với chi phí quản lý thực hiện các chính sách, chế độ trợ cấp một lần theo Quyết định số 290/2005/QĐ-TTg ngày 8/11/2005 và Quyết định số 188/2007/QĐ-TTg ngày 6/12/2007 của Thủ tướng Chính phủ về việc sửa đổi, bổ sung Quyết định số 290/2005/QĐ-TTg của Thủ tướng Chính phủ về chế độ, chính sách đối với một số đối tượng trực tiếp tham gia kháng chiến chống Mỹ cứu nước nhưng chưa được hưởng chính sách của Đảng và Nhà nước, thực hiện theo hướng dẫn tại Thông tư số 191/2005/TTLT-BQP-BLĐTBXH-BTC ngày 7/12/2005 của liên Bộ Quốc phòng, Bộ Lao động – Thương binh và Xã hội và Bộ Tài chính hướng dẫn thực hiện Quyết định số 290/2005/QĐ-TTg ngày 8/11/2005 về chế độ, chính sách đối với một số đối tượng trực tiếp tham gia kháng chiến chống Mỹ cứu nước nhưng chưa được hưởng chính sách của Đảng và Nhà nước và Thông tư liên tịch số 21/2008/TTLT-BLĐTBXH-BTC ngày 26/02/2008 của liên Bộ Quốc phòng - Bộ Lao động – Thương binh và Xã hội – Bộ Tài chính sửa đổi, bổ sung Thông tư số 191/2005/TTLT-BQP-BLĐTBXH-BTC ngày 7/12/2005.