# 773_2018_QĐ_TTg_preamble


| THỦ TƯỚNG CHÍNH PHỦ ------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc --------------- |
|---|---|
| Số: 773 /QĐ-TTg | Hà Nội, ngày 26 tháng 0 6 năm 2018 |

QUYẾT ĐỊNH

BAN HÀNH KẾ HOẠCH TỔ CHỨC THỰC HIỆN CHỈ THỊ SỐ 14-CT/TW NGÀY 19 THÁNG 7 NĂM 2017 CỦA BAN BÍ THƯ TRUNG ƯƠNG ĐẢNG KHÓA XII VỀ TIẾP TỤC TĂNG CƯỜNG SỰ LÃNH ĐẠO CỦA ĐẢNG ĐỐI VỚI CÔNG TÁC NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG

THỦ TƯỚNG CHÍNH PHỦ

Căn cứ Luật Tổ chức Chính phủ ngày 19 tháng 6 năm 2015;

Căn cứ Pháp lệnh Ưu đãi người có công với cách mạng số 26/2005/PL-UBTVQH11 ngày 29 tháng 6 năm 2005 của Ủy ban Thường vụ Quốc hội và Pháp lệnh sửa đổi, bổ sung một số điều của Pháp lệnh Ưu đãi người có công với cách mạng số 04/2012/PL-UBTVQH13 ngày 16 tháng 7 năm 2012 của Ủy ban Thường vụ Quốc hội;

Căn cứ Chỉ thị số 14-CT/TW ngày 19 tháng 7 năm 2017 của Ban Bí thư Trung ương Đảng khóa XII về tiếp tục tăng cường sự lãnh đạo của Đảng đối với công tác người có công với cách mạng;

Xét đề nghị của Bộ trưởng Bộ Lao động - Thương binh và Xã hội,

QUYẾT ĐỊNH: