# 2638_2019_CV_LĐTBXH_KHTC_preamble

B Ộ LAO ĐỘNG - THƯƠNG BINH V À X Ã HỘI
-------
Số: 2638/LĐTBXH-KHTC
V/v xây dựng dự toán ngân sách trung ươ n g thực hiện Pháp lệnh ưu đãi NCC với cách mạng năm 2020 và kế hoạch tài chính - NSNN 03 năm 2020-2022

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
Hà Nội, ngày 03 tháng 7 năm 2019

Kính gửi: Giám đốc Sở Lao động - Thương binh và Xã hội các tỉnh, thành phố trực thuộc Trung ương

Thực hiện Chỉ thị số 16/CT-TTg ngày 25/6/2019 của Thủ tướng Chính phủ về xây dựng Kế hoạch phát triển kinh tế - xã hội và dự toán ngân sách nhà nước năm 2020 và Thông tư số 38/2019/TT-BTC ngày 28/6/2019 của Bộ trưởng Bộ Tài chính hướng dẫn xây dựng dự toán ngân sách nhà nước năm 2020, kế hoạch tài chính - ngân sách nhà nước 03 năm 2020-2022; kế hoạch tài chính 05 năm tỉnh, thành phố trực thuộc trung ương giai đoạn 2021-2025, Bộ hướng dẫn Sở Lao động - Thương binh và Xã hội các tỉnh, thành phố xây dựng dự toán ngân sách trung ương thực hiện Pháp lệnh ưu đãi Người có công với cách mạng năm 2020 và kế hoạch tài chính - ngân sách nhà nước 03 năm giai đoạn 2020-2022 như sau: