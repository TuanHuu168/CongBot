# 2638_2019_CV_LĐTBXH_KHTC_partII_sec1_2

II. Xây dựng dự toán năm 2020

1. Kinh phí chi trả trợ cấp thường xuyên:

Kinh phí chi trả trợ cấp hàng tháng và các khoản trợ cấp 1 lần theo chế độ thường xuyên: Căn cứ Nghị định số 31/2013/NĐ-CP ngày 09/4/2013 của Chính phủ quy định chi tiết, hướng dẫn thi hành một số điều của Pháp lệnh ưu đãi người có công với cách mạng; Nghị định số 56/2013/NĐ-CP ngày 22/5/2013 của Chính phủ quy định chi tiết, hướng dẫn thi hành một số điều của Pháp lệnh quy định danh hiệu vinh dự Nhà nước “Bà mẹ Việt Nam anh hùng”; các Quyết định của Thủ tướng Chính phủ số 142/2008/QĐ-TTg ngày 27/10/2008, số 53/2010/QĐ-TTg ngày 20/8/2010 và số 62/2011/QĐ-TTg ngày 09/11/2011... và tình hình quản lý đối tượng thực tế tại địa phương tại thời điểm báo cáo để xây dựng dự toán kinh phí thực hiện Pháp lệnh ưu đãi người có công với cách mạng năm 2020; mức trợ cấp, phụ cấp căn cứ theo Nghị định số 58/2019/NĐ-CP ngày 01/7/2019 của Chính phủ quy định mức trợ cấp, phụ cấp ưu đãi đối với người có công với cách mạng, tính đủ 12 tháng.

2. Kinh phí chi trả trợ cấp 1 lần

Xây dựng dự toán thực hiện trên cơ sở số hồ sơ của đối tượng còn tồn đọng, tiến độ duyệt hồ sơ và các định mức chi trả theo quy định hiện hành và dự kiến số đối tượng mới, kinh phí thực hiện các chế độ trợ cấp 1 lần theo Quyết định số 290/QĐ-TTg, Quyết định số 59/QĐ-TTg; Quyết định số 62/QĐ-TTg, Quyết định số 40/2011/QĐ-TTg ngày 27/7/2011 của Thủ tướng Chính phủ, Nghị định số 23/2012/NĐ-CP ngày 03/4/2012 của Chính phủ, Nghị định số 56/2013/NĐ-CP của Chính phủ...