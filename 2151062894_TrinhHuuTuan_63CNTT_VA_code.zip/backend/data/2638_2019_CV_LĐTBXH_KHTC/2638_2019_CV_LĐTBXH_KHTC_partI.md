# 2638_2019_CV_LĐTBXH_KHTC_partI

I. Đánh giá tình hình thực hiện nhiệm vụ ngân sách nhà nước năm 2019 và giai đoạn 2016-2019

1. Căn cứ đánh giá tình hình thực hiện nhiệm vụ ngân sách nhà nước năm 2019 và giai đoạn 2016-2019

- Tình hình biến động tăng, giảm đối tượng và số đối tượng thực tế hiện đang hưởng các chế độ trợ cấp giai đoạn 2016-2018; tình hình thực hiện 6 tháng đầu năm và dự kiến thực hiện cả năm 2019.

- Tình hình thực hiện dự toán ngân sách nhà nước giai đoạn 2016-2018 thực hiện Pháp lệnh ưu đãi người có công với cách mạng; tình hình thực hiện 6 tháng đầu năm và dự kiến thực hiện cả năm 2019 (bao gồm cả điều chỉnh, bổ sung - nếu có).

- Các Công văn của Bộ hướng dẫn triển khai dự toán thực hiện Pháp lệnh ưu đãi người có công với cách mạng giai đoạn 2016-2018 và năm 2019.

- Thực hiện các kết luận, kiến nghị của các cơ quan chức năng thanh tra, kiểm toán... trong quản lý kinh phí thực hiện Pháp lệnh ưu đãi người có công.

- Báo cáo đánh giá tình hình thực hiện và những khó khăn, vướng mắc trong quá thực hiện các nhiệm vụ, cơ chế, chính sách và chế độ chi tiêu; đồng thời kiến nghị những giải pháp khắc phục.

2. Đánh giá tình hình thực hiện nhiệm vụ chi thường xuyên năm 2019

Tình hình triển khai phân bổ, giao dự toán và thực hiện dự toán NSNN 6 tháng đầu năm và dự kiến cả năm 2019 kinh phí thực hiện Pháp lệnh ưu đãi người có công với cách mạng; kết quả thực hiện; những khó khăn, vướng mắc và đề xuất biện pháp xử lý.