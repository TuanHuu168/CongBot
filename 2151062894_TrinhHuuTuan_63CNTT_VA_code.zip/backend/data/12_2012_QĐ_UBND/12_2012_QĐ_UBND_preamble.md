# 12_2012_QĐ_UBND_preamble


| UỶ BAN NHÂN DÂN TỈNH TUYÊN QUANG -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------- |
|---|---|
| Số: 12/2012/QĐ-UBND | Tuyên Quang, ngày 25 tháng 6 năm 2012 |

QUYẾT ĐỊNH

VỀ VIỆC BAN HÀNH QUY ĐỊNH TẶNG QUÀ ĐỐI VỚI THƯƠNG BINH, BỆNH BINH, GIA ĐÌNH LIỆT SĨ VÀ NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG TRÊN ĐỊA BÀN TỈNH TUYÊN QUANG

UỶ BAN NHÂN DÂN TỈNH

Căn cứ Luật Tổ chức Hội đồng nhân dân và Ủy ban nhân dân ngày 26/11/2003;

Căn cứ Luật Ban hành văn bản quy phạm pháp luật của Hội đồng nhân dân và Ủy ban nhân dân ngày 03/12/2004;

Căn cứ Pháp lệnh số 26/2005/PL-UBTVQH11 ngày 29/6/2005 ưu đãi người có công với cách mạng và Pháp lệnh số 35/2007/PL-UBTVQH11 ngày 21/6/2007 sửa đổi, bồ sung một số điều của Pháp lệnh ưu đãi người có công với cách mạng;

Căn cứ Nghị định số 54/2006/NĐ-CP ngày 26/5/2006 của Chính phủ hướng dẫn thi hành một số điều của Pháp lệnh ưu đãi người có công với cách mạng và Nghị định số 89/2008/NĐ-CP ngày 13/8/2008 của Chỉnh phủ hướng dẫn thi hành Pháp lệnh sửa đổi bổ sung một số điều của Pháp lệnh ưu đãi người có công với cách mạng;

Xét đề nghị của Giám đốc Sở Lao động - Thương binh và Xã hội tại Tờ trình số 461/TTr-SLĐTBXH ngày 15/5/2012 về việc đề nghị ban hành Quy định tặng quà đối với thương binh, bệnh binh, gia đình liệt sĩ và người có công với cách mạng trên địa bàn tỉnh Tuyên Quang,

QUYẾT ĐỊNH: