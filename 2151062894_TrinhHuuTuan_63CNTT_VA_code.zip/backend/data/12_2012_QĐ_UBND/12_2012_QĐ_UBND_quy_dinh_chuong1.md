# 12_2012_QĐ_UBND_quy_dinh_chuong1

QUY ĐỊNH

VỀ VIỆC TẶNG QUÀ ĐỐI VỚI THƯƠNG BINH, BỆNH BINH, GIA ĐÌNH LIỆT SĨ VÀ NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG TRÊN ĐỊA BÀN TỈNH TUYÊN QUANG (Ban hành kèm theo Quyết định số 12/2012/QĐ-UBND ngày 25/6/2012 của Ủy ban nhân dân tỉnh Tuyên Quang)

Chương I

NHỮNG QUY ĐỊNH CHUNG

Điều 1. Quy định này quy định về việc tặng quà nhân ngày Thương binh liệt sĩ 27 tháng 7, Quốc khánh 2 tháng 9 và Tết Nguyên đán cổ truyền hằng năm; mức quà tặng; trách nhiệm của các cơ quan có liên quan, Ủy ban nhân dân huyện, thành phố, các xã phường, thị trấn trong quản lý và tổ chức thực hiện việc tặng quà đối với các đối tượng chính sách.

Điều 2. Một số quy định chung:

1. Trường hợp một người được xác nhận là hai đối tượng trở lên đủ điều kiện hưởng cả hai mức quà theo quy định thì chỉ được nhận một suất quà với mức cao nhất, hoặc đủ điều kiện hưởng hai mức quà có giá trị bằng nhau thì chỉ được nhận một mức quà ở mức đó.

2. Mỗi một liệt sĩ thì đại diện gia đình thờ cúng liệt sĩ được nhận một suất quà.

3. Ngoài việc được tặng quà theo quy định này, một số đối tượng gia đình chính sách tiêu biểu được Lãnh đạo Tỉnh ủy, Hội đồng nhân dân, Ủy ban nhân dân tỉnh tới thăm, tặng quà nhân dịp Tết Nguyên đán cổ truyền, ngày Thương binh liệt sĩ 27 tháng 7; mức quà do Ủy ban nhân dân tỉnh quy định cụ thể theo từng lần đến thăm hằng năm.

4. Khuyến khích các tổ chức, cá nhân tham gia thăm hỏi, tặng quà đối tượng chính sách bằng những hình thức ý nghĩa và phù hợp.