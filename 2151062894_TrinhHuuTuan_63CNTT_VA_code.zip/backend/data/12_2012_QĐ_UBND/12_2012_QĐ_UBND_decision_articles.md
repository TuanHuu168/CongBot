# 12_2012_QĐ_UBND_decision_articles

Điều 1. Ban hành kèm theo Quyết định này Quy định về việc tặng quà đối với thương binh, bệnh binh, gia đình liệt sĩ, người có công với cách mạng trên địa bàn tỉnh Tuyên Quang.

Điều 2. Giám đốc Sở Lao động - Thương binh và Xã hội có trách nhiệm chủ trì, phối hợp với các cơ quan liên quan tổ chức triển khai, hướng dẫn, kiểm tra việc thực hiện Quyết định này.

Điều 3. Quyết định này có hiệu lực sau 10 ngày kể từ ngày ký và thay thế các Quyết định: Quyết định số 110/2005/QĐ-UBND ngày 29/12/2005 của Ủy ban nhân dân tỉnh về việc ban hành Quy định tặng quà đối với thương binh, bệnh binh, gia đình liệt sĩ, người có công với cách mạng trên địa bàn tỉnh Tuyên Quang; Quyết định số 42/2007/QĐ-UBND ngày 31/12/2007 của Ủy ban nhân dân tỉnh về việc sửa đổi, bổ sung một số diều của Quy định ban hành kèm theo Quyết định số 110/2005/QĐ-UBND ngày 29/12/2005 của Ủy ban nhân dân tỉnh.

Các ông (bà): Chánh Văn phòng Ủy ban nhân dân tỉnh, Giám đốc Sở Lao động - Thương binh và Xã hội, Giám đốc Sở Tài chính, thủ trưởng các cơ quan liên quan, Chủ tịch Ủy ban nhân huyện, thành phố chịu trách nhiệm thi hành Quyết định này./.

| Nơi nhận: - Văn phòng Chính phủ; - Bộ Lao động - TB và XH; (báo cáo) - Thường trực Tỉnh uỷ; - Thường trực HĐND tỉnh; - Đoàn ĐBQH địa phương; - Chủ tịch, các PCT UBND tỉnh; - Như Điều 2; (thực hiện) - Cục Kiểm tra văn bản - Bộ Tư pháp; - UBMTTQ và các đoàn thể cấp tỉnh; - Các sở, ban, ngành; - Trung tâm Công báo tỉnh; - Các Phó CVP UBND tỉnh; - Các Trưởng phòng NCTH; - Lưu VT, VX. | TM. UỶ BAN NHÂN DÂN TỈNH CHỦ TỊCH Chẩu Văn Lâm |
|---|---|