# 12_2012_QĐ_UBND_quy_dinh_chuong2_art4

Điều 4. Thời gian tặng quà và mức quà tặng:

1. Tặng quà (một lần) vào ngày Thương binh liệt sĩ 27 tháng 7:

1.1. Nhóm đối tượng số 5 quy định tại Điều 3 của quy định này: 2.000.000 đồng/đơn vị.

1.2. Nhóm đối tượng số 6 quy định tại Điều 3 của quy định này: 400.000 đồng/người.

1.3. Nhóm đối tượng số 1 quy định tại Điều 3 của quy định này: 300.000 đồng/người.

1.4. Nhóm đối tượng số 3 quy định tại Điều 3 của quy định này: 150.000 đồng/người.

2. Tặng quà (một lần) vào ngày Quốc khánh 2 tháng 9:

2.1. Nhóm đối tượng số 2 quy định tại Điều 3 của quy định này: 300.000 đồng/người.

2.2. Nhóm đối tượng số 4 quy định tại Điều 3 của quy định này: 150.000 đồng/nguời.

3. Tặng quà (một lần) vào ngày Tết Nguyên đán cổ truyền:

3.1. Nhóm đối tượng số 5 quy định tại Điều 3 của quy định này: 2.000.000 đồng/đơn vị.

3.2. Nhóm đối tượng số 6 quy định tại Điều 3 của quy định này: 400.000 đồng/nguời.

3.3. Nhóm đối tượng số 1, 2 quy định tại Điều 3 của quy định này: 300.000 đồng/người.

3.4. Nhóm đối tượng số 3, 4 quy định tại Điều 3 của quy định này: 150.000 đồng/người.