# 12_2012_QĐ_UBND_quy_dinh_chuong2_art3

Chương II

CÁC QUY ĐỊNH CỤ THỂ

Điều 3. Đối tượng tặng quà, gồm:

1. Nhóm đối tượng số 1:

1.1. Bà mẹ Việt Nam anh hùng đang hưởng trợ cấp nuôi dưỡng và phụ cấp hằng tháng.

1.2. Thương binh, người hưởng chính sách như thương binh bị suy giảm khả năng lao động do thương tật từ 81% trở lên (bao gồm cả những thương binh loại B được công nhận từ trước ngày 31 tháng 12 năm 1993) đang hưởng trợ cấp ưu đãi hằng tháng.

1.3. Bệnh binh bị suy giảm khả năng lao động do bệnh tật từ 81% trở lên đang hưởng trợ cấp ưu đãi hằng tháng.

1.4. Thân nhân hai liệt sĩ trở lên đang hưởng trợ cấp tuất hằng tháng.

1.5. Thân nhân liệt sĩ đang hưởng trợ cấp tuất nuôi dưỡng hằng tháng.

1.6. Người hoạt động kháng chiến bị nhiễm chất độc hóa học suy giảm khả năng lao động từ 81% trở lên đang hưởng trợ cấp ưu đãi hằng tháng.

2. Nhóm đối tượng số 2:

2.1. Người hoạt động cách mạng trước ngày 01/01/1945 đang hưởng trợ cấp ưu đãi hằng tháng.

2.2. Người hoạt động cách mạng từ ngày 01/01/1945 đến trước Tổng khởi nghĩa 19 tháng 8 năm 1945 đang hưởng trợ cấp ưu đãi hằng tháng.

2.3. Người có công giúp đỡ cách mạng trước cách mạng tháng Tám năm 1945 đang hưởng trợ cấp nuôi dưỡng hằng tháng.

2.4. Người có công giúp đỡ cách mạng trong kháng chiến đang hưởng trợ cấp nuôi dưỡng hằng tháng.

3. Nhóm đối tượng số 3:

3.1. Thương binh, người hưởng chính sách như thương binh bị suy giảm khả năng lao động do thương tật từ 21% đến 80% (bao gồm cả những thương binh loại B được công nhận từ trước ngày 31 tháng 12 năm 1993) đang hưởng trợ cấp ưu đãi hằng tháng.

3.2. Bệnh binh bị suy giảm khả năng lao động do bệnh tật từ 41% đến 80% đang hưởng trợ cấp ưu đãi hằng tháng.

3.3. Đại diện thân nhân chủ yếu của liệt sĩ.

3.4. Đại diện gia đình thờ cúng liệt sĩ (anh, chị, em, người được họ tộc ủy nhiệm việc thờ cúng liệt sĩ và giữ bản gốc Bằng Tổ quốc ghi công).

3.5. Người hoạt động cách mạng hoặc hoạt động kháng chiến bị địch bắt tù, đày đã được hưởng trợ cấp một lần hiện còn sống.

3.6. Người hoạt động kháng chiến bị nhiễm chất độc hóa học suy giảm khả năng lao động từ 80% trở xuống đang hưởng trợ cấp ưu đãi hằng tháng.

3.7. Con đẻ của người hoạt động kháng chiến bị nhiễm chất độc hóa học bị dị dạng, dị tật đang hưởng trợ cấp ưu đãi hằng tháng.

4. Nhóm đối tượng số 4:

4.1. Người có công giúp đỡ cách mạng trước cách mạng tháng Tám năm 1945 đang hưởng trợ cấp ưu đãi hằng tháng.

4.2. Người có công giúp đỡ cách mạng trong kháng chiến đang hưởng trợ cấp ưu đãi hằng tháng.

5. Nhóm đối tượng số 5: Tập thể cán bộ công nhân viên chức phục vụ tại các Trung tâm điều dưỡng thương binh, người có công có thương binh, bệnh binh nặng của tỉnh đang điêu dưỡng.

6. Nhóm đối tượng số 6: Thương binh, bệnh binh nặng của tỉnh đang điều dưỡng tập trung tại các Trung tâm điều dưỡng thương binh (người có công).