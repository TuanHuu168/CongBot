# 12_2012_QĐ_UBND_quy_dinh_chuong3

Chương III

TỔ CHỨC THỰC HIỆN

Điều 5. Giao trách nhiệm:

1. Sở Lao động - Thương binh và Xã hội:

Hằng năm xây dựng kế hoạch, dự toán kinh phí tặng quà đối với các đối tượng chính sách trình Ủy ban nhân dân tỉnh phê duyệt.

Phối hợp với Ủy ban nhân dân huyện, thành phố tổ chức việc trao tặng quà đảm bảo kịp thời, chu đáo và đúng quy định của tỉnh.

- Triển khai, hướng dẫn, đôn đốc các cơ quan, đơn vị trong tỉnh thực hiện quy định này.

- Định kỳ tổng hợp, báo cáo tình hình kết quả các hoạt động thăm hỏi, tặng quà các gia đình chính sách trên địa bàn với Ủy ban nhân dân tỉnh và Bộ Lao động - Thương binh và Xã hội theo quy định.

2. Sở Tài chính, Kho bạc Nhà nước tỉnh: Thẩm định dự toán, cấp kinh phí, hướng dẫn kiểm tra việc tặng quà đến các đối tượng chính sách, thanh quyết toán theo đúng quy định của Luật Ngân sách Nhà nước.

3. Ủy ban nhân dân huyện, thành phố có trách nhiệm chỉ đạo Phòng Lao động - Thương binh và Xã hội, Ủy ban nhân dân các xã, phường, thị trấn lập danh sách đối tượng, tổ chức tiếp nhận và trao quà đến các đối tượng chính sách đầy đủ, kịp thời; báo cáo kết quả các hoạt động thăm hỏi, tặng quà trên địa bàn với ủy ban nhân dân tỉnh (qua Sở Lao động - Thương binh và Xã hội tổng hợp) theo quy định.

4. Ủy ban nhân dân xã, phường, thị trấn có trách nhiệm tiếp nhận quà, tổ chức gặp mặt thăm hỏi và trao quà đến các đối tượng chính sách đảm bảo trang trọng, chu đáo.

Điều 6. Quy định này được phổ biến rộng rãi đến các cơ quan, ban, ngành, địa phương trong tỉnh.

Trong quá trình thực hiện nếu có khó khăn vướng mắc vượt thẩm quyền giải quyết các sở, ban, ngành, Ủy ban nhân dân các huyện, thành phố và các cơ quan liên quan tổng hợp báo cáo Ủy ban nhân dân tỉnh để xem xét chỉ đạo giải quyết kịp thời./