# 31_2011_QD_UBND_quy_dinh_chuong2_art3_5

Chương II

CHẾ ĐỘ MIỄN GIẢM CỤ THỂ

Điều 3. Phạm vi đối tượng

Đối tượng áp dụng chế độ miễn, giảm là người có công với cách mạng hiện đang gặp hoàn cảnh thật sự khó khăn về nhà ở, đất ở theo quy định tại Khoản 1, Điều 1, Quyết định số 117/2007/QĐ-TTg ngày 25/7/2007 về việc sửa đổi, bổ sung một số điều của Quyết định số 118/QĐ-TTg ngày 27/02/1996 của Thủ tướng Chính phủ về việc hỗ trợ người có công với cách mạng cải thiện nhà ở.

Điều 4. Miễn tiền sử dụng đất

Người có công với cách mạng khi được giao đất ở, được phép chuyển mục đích sử dụng, được công nhận hoặc được cấp giấy chứng nhận quyền sử dụng đất ở thì được miễn tiền sử dụng đất cho các đối tượng là: Bà mẹ Việt Nam Anh hùng; Anh hùng Lực lượng vũ trang nhân dân, Anh hùng lao động; thương binh, người hưởng chính sách như thương binh, thương binh loại B, bệnh binh có tỷ lệ suy giảm khả năng lao động do thương tật, bệnh tật từ 81% trở lên; thân nhân của liệt sỹ đang hưởng tiền tuất nuôi dưỡng hàng tháng.

Điều 5. Giảm tiền sử dụng đất

Giảm tiền sử dụng đất trong hạn mức đất ở do UBND tỉnh quy định cho các đối tượng là người có công với cách mạng khi được giao đất ở, được phép chuyển mục đích sử đích sử dụng, được công nhận hoặc được cấp giấy chứng nhận quyền sử dụng đất ở như sau:

1. Giảm 90% tiền sử dụng đất cho các đối tượng là: Người hoạt động kháng chiến bị nhiễm chất độc hóa học; thương binh, người hưởng chính sách như thương binh, thương binh loại B, bệnh binh có tỷ lệ suy giảm khả năng lao động do thương tật, bệnh tật từ 61% đến 80%;

2. Giảm 80% tiền sử dụng đất cho các đối tượng là: Thương binh, người hưởng chính sách như thương binh, thương binh loại B, bệnh binh, có tỷ lệ suy giảm khả năng lao động do thương tật, bệnh tật từ 41% đến 60%;

3. Giảm 70% tiền sử dụng đất cho các đối tượng là: Thân nhân của liệt sỹ quy định tại Khoản 1, Điều 14 của Pháp lệnh ưu đãi người có công với cách mạng (được cơ quan Nhà nước có thẩm quyền cấp “Giấy chứng nhận gia đình liệt sỹ”, gồm: Cha đẻ, mẹ đẻ; vợ hoặc chồng; con; người có công nuôi dưỡng khi liệt sỹ còn nhỏ, bao gồm cả các trường hợp có hoặc không được hưởng trợ cấp hàng tháng); thương binh, người hưởng chính sách như thương binh, thương binh loại B có tỷ lệ suy giảm khả năng lao động do thương tật từ 21% đến 40%; người có công giúp đỡ cách mạng đang được hưởng trợ cấp hàng tháng; người có công giúp đỡ cách mạng được tặng Kỷ niệm chương “Tổ quốc ghi công” hoặc Bằng “Có công với nước”;

4. Giảm 65% tiền sử dụng đất cho các đối tượng là: Người hoạt động cách mạng, hoạt động kháng chiến bị địch bắt tù đày; người hoạt động kháng chiến giải phóng dân tộc, bảo vệ Tổ quốc và làm nghĩa vụ quốc tế được tặng thưởng Huân chương Kháng chiến hạng I hoặc Huân chương Chiến thắng hạng I.