# 31_2011_QD_UBND_preamble


| UỶ BAN NHÂN DÂN TỈNH GIA LAI -------- | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM Độc lập - Tự do - Hạnh phúc ---------------- |
|---|---|
| Số: 31/2011/QĐ-UBND | Gia Lai, ngày 10 tháng 11 năm 2011 |

QUYẾT ĐỊNH

VỀ VIỆC BAN HÀNH QUY ĐỊNH TRÌNH TỰ, THỦ TỤC GIẢI QUYẾT CHẾ ĐỘ MIỄN, GIẢM TIỀN SỬ DỤNG ĐẤT ĐỐI VỚI NGƯỜI CÓ CÔNG VỚI CÁCH MẠNG TRÊN ĐỊA BÀN TỈNH GIA LAI

UỶ BAN NHÂN DÂN TỈNH

Căn cứ Luật Tổ chức HĐND và UBND năm 2003;

Căn cứ Nghị định số 89/2008/NĐ-CP ngày 13/8/2008 của Chính phủ hướng dẫn thi hành Pháp lệnh sửa đổi, bổ sung một số Điều của Pháp lệnh ưu đãi người có công với cách mạng; Nghị định số 198/2004/NĐ-CP ngày 03/12/2004 của Chính phủ về thu tiền sử dụng đất; Nghị định số 44/2008/NĐ-CP ngày 09/4/2008 của Chính phủ về sửa đổi, bổi sung một số Điều của Nghị định số 198/2004/NĐ-CP .

Căn cứ Quyết định số 118/TTg ngày 27/02/1996 của Thủ tướng Chính phủ về việc hỗ trợ người có công với cách mạng cải thiện nhà ở; Quyết định số 117/2007/QĐ-TTg ngày 25/7/2007 của Thủ tướng Chính phủ về việc sửa đổi, bổ sung một số Điều của Quyết định số 118/TTg ngày 27/02/1996 và Điều 3, Quyết định số 20/2000/QĐ-TTg ngày 03/02/2000 của Thủ tướng Chính phủ về việc hỗ trợ người hoạt động cách mạng từ trước cách mạng tháng Tám năm 1945 cải thiện nhà ở.

Căn cứ Thông tư số 117/2004/TT-BTC ngày 07/12/2004 của Bộ Tài chính Xét đề nghị của Cục Thuế tỉnh Gia Lai tại Tờ trình số 2520/TTr-CT ngày 12/10/2011,

QUYẾT ĐỊNH: