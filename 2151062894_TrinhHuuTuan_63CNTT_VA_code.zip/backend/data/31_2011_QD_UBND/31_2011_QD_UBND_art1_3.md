# 31_2011_QD_UBND_art1_3

Điều 1. Ban hành kèm theo Quyết định này là Quy định về trình tự, thủ tục giải quyết chế độ miễn, giảm tiền sử dụng đất cho người có công với cách mạng trên địa bàn tỉnh Gia Lai.

Điều 2. Quyết định này có hiệu lực thi hành sau 10 ngày, kể từ ngày ký.

Điều 3. Chánh văn phòng UBND tỉnh; Giám đốc các Sở: Lao động Thương binh và Xã hội, Tài chính; Cục trưởng Cục Thuế tỉnh; Chủ tịch UBND các Huyện, Thị xã, Thành phố; Thủ trưởng các Ban, ngành liên quan của tỉnh chịu trách nhiệm thi hành Quyết định này./.

|  | TM. UỶ BAN NHÂN DÂN TỈNH CHỦ TỊCH Phạm Thế Dũng |
|---|---|