# 31_2011_QD_UBND_quy_dinh_chuong4_art8_9

Chương IV

TỔ CHỨC THỰC HIỆN

Điều 8.

1. Chủ tịch Ủy ban nhân dân các Huyện, Thị xã, Thành phố có trách nhiệm chỉ đạo và hướng dẫn cho UBND cấp Xã, Phường, Thị trấn thực hiện theo khoản 1, Điều 7 Quy định này.

2. Chủ tịch Ủy ban nhân dân các Huyện, Thị xã, Thành phố; Thủ trưởng các Sở, Ban, Ngành nêu tại Điều 7 Quy định này chịu trách nhiệm giải quyết việc miễn, giảm tiền sử dụng đất cho các đối tượng là người có công với cách mạng theo đúng Quy định này.

Điều 9. Trong quá trình thực hiện nếu có vướng mắc, chủ tịch Ủy ban nhân dân các Huyện, Thị xã, Thành phố tổng hợp, báo cáo về Cục Thuế tỉnh để xem xét, hướng dẫn giải quyết; trường hợp phức tạp Cục Thuế tỉnh báo cáo và đề xuất ý kiến cho Ủy ban nhân dân tỉnh xem xét, quyết định./.